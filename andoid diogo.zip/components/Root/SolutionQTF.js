import React from "react";

import Wallpaper from './Wallpaper';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';

var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 5000) break;
        }
        
    }
};

var nexType;
var counterInt=0;

export default class QuestionQTF extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {

            enunciated: '',
            question:'',
            questions:[],
            answersList:[],

            counter:'',

            answersListTotal:[],

            username: '',
            verifier: '',
        };

    }

    componentWillMount(){

        const counterJSON = SyncStorage.get('CS')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })
        counterInt = counter.counter;

        const CQJSON = SyncStorage.get('CQ' + counterInt)
        var CQ = JSON.parse(CQJSON);

        var questionQTF = CQ.question;

        this.setState({ enunciated: questionQTF.enunciated })
        this.setState({ question: questionQTF.question })
        var questionsFromDB = questionQTF.questionsList.questions;
        var answersListFromDB = questionQTF.answersList.answersList;

        this.setState({ questions: questionsFromDB })
        this.setState({ answersList: answersListFromDB })

        return false;
    }


    componentDidMount(){

        if(counterInt==10){
            return false;
        }

        var i = counterInt +1;
        var CTJSON = SyncStorage.get('CT'+ i);
        var CT = JSON.parse(CTJSON);
        nexType = CT.type;

        this.CDM();
    }

    CDM(){
        var i = counterInt +1;
        var CS = {counter : i};
        SyncStorage.set('CS', JSON.stringify(CS));
    }


    enuncitedShow(){
        return this.state.enunciated;
    }

    questionShow(){
        return this.state.question;
    }
    questionTFShow(x){
        return this.state.questions[x];
    }
    skip(){
        Actions.FinishQuizz();
    }


    nextQuestion(){

        var number = counterInt;
        var number1 = number.toString();
        //alert(number1.localeCompare("10"));

        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.SOLQMC();
        }else if(nexType==1){
            Actions.SOLQO();
        }else{
            Actions.SOLQTF();
        }
        
    }

   radioShow(valueOf, id){
        if(this.state.answersList[id] == valueOf){
            return 'checked';
        }else{
            return 'unchecked';
        }
        
    }

    getCounter(){
        return this.state.counter;
    }

    contentSizeChange = ({nativeEvent:event}) => {
        this.setState({ textAreaHeight: event.contentSize.height });
    };

    render() {

        const {textAreaHeight} = this.state;

        return (
            <Wallpaper>
                <Text style={styles.textEnunciated}>Solution nº {this.getCounter()}</Text>
                <Text style={styles.textEnunciated}>Enunciated</Text>
                <View style={styles.textViewEnunciatedMain}>
                    
                    <ScrollView /*style={styles.textEnunciatedMain}*/>  
                        
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.enuncitedShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>


                <Text style={styles.textEnunciated}>Question</Text>
                <View style={styles.textViewQuestionMain} >
                    <ScrollView>
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.questionShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>

                <ScrollView nestedScrollEnabled = {true}>


                    <RadioButton.Group
                        //onValueChange={answer1 => this.setState({ answer1 })}
                        //value={this.state.answer1}
                    >
                        <View style={styles.textViewOptionMain} >
                            <Text style={styles.textOption}>Question A</Text>
                            <View style={styles.radioButtons} >
                                <RadioButton 
                                    value = "T" 
                                    color={Colors.green500} 
                                    uncheckedColor={Colors.green500}
                                    status={this.radioShow("T", 0)}
                                />
                                <RadioButton 
                                    value = "F" 
                                    color={Colors.red500} 
                                    uncheckedColor={Colors.red500}
                                    status={this.radioShow("F", 0)}
                                />
                            </View>

                            <View style={styles.textViewOption} >
                                <ScrollView nestedScrollEnabled = {true}>
                                    <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                        value={this.questionTFShow(0)}
                                        onContentSizeChange={this.contentSizeChange}
                                        multiline
                                        editable = {false}
                                    />
                                </ScrollView>
                            </View>


                        </View>
                    </RadioButton.Group>


                    <RadioButton.Group
                        //onValueChange={answer2 => this.setState({ answer2 })}
                        //value={this.state.answer2}
                    >
                        <View style={styles.textViewOptionMain} >
                            <Text style={styles.textOption}>Question B</Text>
                            <View style={styles.radioButtons} >
                                <RadioButton 
                                    value = "T" 
                                    color={Colors.green500} 
                                    uncheckedColor={Colors.green500}
                                    status={this.radioShow("T", 1)}
                                />
                                <RadioButton 
                                    value = "F" 
                                    color={Colors.red500} 
                                    uncheckedColor={Colors.red500}
                                    status={this.radioShow("F", 1)}
                                />
                            </View>

                            <View style={styles.textViewOption} >
                                <ScrollView nestedScrollEnabled = {true}>
                                    <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                        value={this.questionTFShow(1)}
                                        onContentSizeChange={this.contentSizeChange}
                                        multiline
                                        editable = {false}
                                    />
                                </ScrollView>
                            </View>
                        </View>
                    </RadioButton.Group>

                    <RadioButton.Group
                        //onValueChange={answer3 => this.setState({ answer3 })}
                        //value={this.state.answer3}
                    >
                        <View style={styles.textViewOptionMain} >
                            <Text style={styles.textOption}>Question C</Text>
                            <View style={styles.radioButtons} >
                                <RadioButton 
                                    value = "T" 
                                    color={Colors.green500} 
                                    uncheckedColor={Colors.green500}
                                    status={this.radioShow("T", 2)}
                                />
                                <RadioButton 
                                    value = "F" 
                                    color={Colors.red500} 
                                    uncheckedColor={Colors.red500}
                                    status={this.radioShow("F", 2)}
                                />
                            </View>

                            <View style={styles.textViewOption} >
                                <ScrollView nestedScrollEnabled = {true}>
                                    <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                        value={this.questionTFShow(2)}
                                        onContentSizeChange={this.contentSizeChange}
                                        multiline
                                        editable = {false}
                                    />
                                </ScrollView>
                            </View>


                        </View>
                    </RadioButton.Group>


                    <RadioButton.Group
                        //onValueChange={answer4 => this.setState({ answer4 })}
                        //value={this.state.answer4}
                    >
                        <View style={styles.textViewOptionMain} >
                            <Text style={styles.textOption}>Question D</Text>
                            <View style={styles.radioButtons} >
                                <RadioButton 
                                    value = "T" 
                                    color={Colors.green500} 
                                    uncheckedColor={Colors.green500}
                                    status={this.radioShow("T", 3)}
                                />
                                <RadioButton 
                                    value = "F" 
                                    color={Colors.red500} 
                                    uncheckedColor={Colors.red500}
                                    status={this.radioShow("F", 3)}
                                />
                            </View>

                            <View style={styles.textViewOption} >
                                <ScrollView nestedScrollEnabled = {true}>
                                    <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                        value={this.questionTFShow(3)}
                                        onContentSizeChange={this.contentSizeChange}
                                        multiline
                                        editable = {false}
                                    />
                                </ScrollView>
                            </View>


                        </View>
                    </RadioButton.Group>


                    <TouchableHighlight style ={styles.skipButton}>
                        <Button onPress={()=> {this.skip()}}            
                        title="SKIP"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 

                    <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.nextQuestion()}}            
                        title="NEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 
                    <Text> </Text>
                    <Text> </Text>
                </ScrollView>
            </Wallpaper>
        );

        
    }

}

const styles = StyleSheet.create({

    textViewEnunciatedMain: {
        maxHeight: 160,
        borderWidth: 3,
        borderColor: 'black',
     },

     textViewQuestionMain: {
        maxHeight: 100,
        borderWidth: 3,
        borderColor: 'black',
     },

    textEnunciated: {
        marginLeft: 10,
        fontSize: 18,
        color: 'white',
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textAreaEnunciated: {
        fontSize: 15,
        color: 'black',
        backgroundColor: 'silver',
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textOption: {
        marginLeft: 10,
        fontSize: 16,
        color: Colors.orange500,
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textViewOptionMain: {
        // height: 'auto',
        marginTop:10,

     },

    textViewOption: {
        maxHeight: 160,
        borderColor: 'black',
        marginTop:-70,
        // height: 'auto',
         marginLeft: 35,
        // borderColor: '#c0c0c0',
         borderWidth: 3,
         padding: 0,
     },

     radioButtons: {
        marginTop:0,
     },

     textAreaOption: {
        backgroundColor: 'silver',
        fontSize: 15,
        color: 'black',
        height: 100,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },
    skipButton: {
        
        height: 40,
        width:100,
        marginLeft :70,
        marginTop :20,
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :200,
        marginTop :-40,
    },
  })
