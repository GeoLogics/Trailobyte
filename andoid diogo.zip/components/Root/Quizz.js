//copiar codigo loginScreen e adaptar
//adicionar ao Root.js
//se tiver alguma duvida verificar zip "src Diogo para o final com as cenas do joao"
//e
//se tiver alguma duvida verificar zip "src diogo com QO validate old look"
//estao ambos no ambiente de trabalho


import React from "react";

import AsyncStorage from '@react-native-community/async-storage';


//import UserForm from './UserForm';
import Wallpaper from './Wallpaper';


import {targetUri as appEngineUri} from '../../app.json';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';


import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';


var questionQMC = {//enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   enunciated:"Qual é a espessura média da crosta continental?",

                   //question: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   question:"escolha a opcao correta",

                   
                   
                   /*optionA: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionB: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionC: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionD: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   */
                   optionA:"7 km",
                   optionB:"35 km",
                   optionC:"1 km",
                   optionD:"100 km",
                   correctOption:"B",
                   id:5
                };

var questionQO = {
                //enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                enunciated: "Ordena as frases de modo a reconstituir a sequência cronológica dos acontecimentos associados a um ciclo oceânico completo (implica o processo de abertura e fecho de um oceano, com a consequente formação de uma cadeia orogénica).",
                question: "Ordena as frases",
                options: {
                    options: ["Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
                                "Início do alargamento de um oceano primitivo.", 
                                "Formação de cadeias montanhosas de colisão.",
                                "Instalação de vulcanismo andesítico em margens continentais ativas.",
                                "Estiramento de crosta continental."]
                },
                byOrder:{
                    byOrder:["option5", "option2", "option1", "option4", "option3"]
                },
                id:""
            };

 //"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
var questionQTF = {
                enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                question: "Classifique como verdadeira ou falsa cada uma das seguintes afirmações, relativas a características da Lua.",
                questionsList: {
                    questions: ["Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",
                                  "Terrae (os continentes) são zonas claras, ricas em minerais félsicos.",
                                  "A erosão tem reduzido o número de crateras de impacto nos mares.",
                                  "Maria (os mares) são zonas escuras, ricas em minerais ferromagnesianos."]
                },
                answersList:{
                    answersList:["T", "T", "F", "T"]
                },
                id:1,
                numberOfQuestions:4
            };
//"Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",

var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 1200) break;
        }
        
    }
};


var randomArray=[];

var arrayOfQMC=[];
var arrayOfQO=[];
var arrayOfQTF=[];




/*var maxQMC =0;
var maxQO =0;
var maxQTF =0;*/



export default class Quizz extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            Q: null,

            username: '',
            verifier: '',

            maxQMC: 0,
            maxQO: 0,
            maxQTF: 0,
        };
        //this.start();

        /*this.getNumberOfQuestions('QMC');
        this.getNumberOfQuestions('QO');
        this.getNumberOfQuestions('QTF');*/
        //Thread.sleep();
    
    }


    genrateRandoms(){

        var counterQMC =0;
        var counterQO =0;
        var counterQTF =0;


        for(var i=0; i < 10; i++){
            //gerar random entre 0 e 2
            var randomNumber = Math.floor(Math.random() * 3);
            //adicionar a posicao i o random gerado

            if(randomNumber==0){
                if(counterQMC < maxQMC){
                    randomArray.push(randomNumber);
                    counterQMC++;
                }else{
                    i--;
                }
                
            }
            else if(randomNumber==1){
                if(counterQO < maxQO){
                    randomArray.push(randomNumber);
                    counterQO++;
                }else{
                    i--;
                }
            }
            else{
                if(counterQTF < maxQTF){
                    randomArray.push(randomNumber);
                    counterQTF++;
                }else{
                    i--;
                }
            }
        }
        console.log('cenas');
        //alert(randomArray);
        //Thread.sleep();

    }
//recebe index do array
    translateIntToType(j){

        var i = randomArray[j];

        if(i==0){
            return "QMC";
        }else if(i==1){
            return "QO";
        }
        else{
            return "QTF";
        }
1    }



    
    async getQuestion(questionType, questionId) {
        try {
            // Get items from AsyncStorage
            const usernameValue = await AsyncStorage.getItem('username');
            const verifierValue = await AsyncStorage.getItem('verifier');
            
            // Set current username
            if (usernameValue !== null) {
                console.log(usernameValue);
                this.setState({username: usernameValue});
            }
            
            // Set current verifier
            if (verifierValue !== null) {
                console.log(verifierValue);
                this.setState({verifier: verifierValue});
            }
        } catch (error) {
            // Failed to load data from AsyncStorage
        }
        
        await fetch(appEngineUri + '/rest/question/OPG' + questionType + '1OP/' + questionId, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : this.state.username,
                'Authorization' : 'Bearer ' + this.state.verifier,
            },
        })
        .then(function(response) {
                console.log(response);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error(response.status);
                }
            })
        .then(data => {
            console.log(data);
            //var temp = await response.json();
            this.setState({Q: data});
            //this.setState({question: data});
        })
        .catch((error) => { alert(error); })
        .done();
    }

//recebe index do array
    genareteIdOfQuestion(i){

        var type = this.translateIntToType(i);

        var bool = false;
        var randomNumber=0;

        if(type == "QMC"){

            while (!bool){
                randomNumber = Math.floor(Math.random() * maxQMC) + 1;
                if(!arrayOfQMC.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQMC.push(randomNumber);
            arrayOfQO.push(null);
            arrayOfQTF.push(null);

            //this.getDatastoreQMC(randomNumber);
            
            /*alert("QMC number: " + randomNumber);
            Thread.sleep();*/


        }else if(type == "QO"){

            while (!bool){
                randomNumber = Math.floor(Math.random() * maxQO) + 1;
                if(!arrayOfQO.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQO.push(randomNumber);
            arrayOfQMC.push(null);
            arrayOfQTF.push(null);

            //this.getDatastoreQO(randomNumber);

            /*alert("QO number: " + randomNumber);
            Thread.sleep();*/

        }else{

            while (!bool){
                randomNumber = Math.floor(Math.random() * maxQTF) + 1;
                if(!arrayOfQTF.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQTF.push(randomNumber);

            arrayOfQMC.push(null);
            arrayOfQO.push(null);
            

            //this.getDatastoreQTF(randomNumber);

            /*alert("QTF number: " + randomNumber);
            Thread.sleep();*/
        }

    }

    set(){
        //for(var j=0; j < 10; j++)
        //chamar this.getDatastore(j) j== index do for(j)
        //o SS.set do counter mantem-se, os outros retiram-se
        var counter = {counter : 1};
        SyncStorage.set('counter', JSON.stringify(counter));


        for(var j=0; j < 10; j++){
         this.genareteIdOfQuestion(j);
        }

        for(var j=0; j < 10; j++){
            var i = j+1;
            var CT = {counter : i, type: randomArray[j]};
            SyncStorage.set('CT'+ i, JSON.stringify(CT));
        }
/*
        for(var j=1; j < 11; j++){
            var CT = SyncStorage.get('CT'+ j);
            alert(CT);
            Thread.sleep();
        }
*/

        var type = randomArray[0];
        var Q;
        if(type==0){
            var id = arrayOfQMC[0];
           // Q=questionQMC;
            //this.getDatastoreQMC(id);
            this.getQuestion('QMC', id);
        }else if(type==1){
            var id = arrayOfQO[0];
            //Q=questionQO;
            //this.getDatastoreQO(id);
            this.getQuestion('QO', id);
        }else{
            var id = arrayOfQTF[0];
            //Q=questionQTF;
            //this.getDatastoreQTF(id);
            this.getQuestion('QTF', id);
        }

        
        //daqui para baixo noutro butao

        //Thread.sleep();


    }



    set1(){
        var type = randomArray[0];
        //var cenas = this.state.Q;
        //var Q1 = JSON.parse(cenas);
        //console.log("set1: ",this.state.Q);
        //console.log("Q1: ",Q1);
        var CQ = {counter : 1, question: this.state.Q};
        SyncStorage.set('CQ' + 1, JSON.stringify(CQ));
        console.log("CQ: ",CQ);
        /*var cenas = SyncStorage.get('CQ' + 1);
        alert(cenas);*/
        
        //console.log("CQ: "+CQ);
        //alert(Q);
        var arrayQMC = {array : arrayOfQMC};
        var arrayQO = {array : arrayOfQO};
        var arrayQTF = {array : arrayOfQTF};

        SyncStorage.set('arrayQMC', JSON.stringify(arrayQMC));
        SyncStorage.set('arrayQO', JSON.stringify(arrayQO));
        SyncStorage.set('arrayQTF', JSON.stringify(arrayQTF));

        randomArray=[];
        arrayOfQMC=[];
        arrayOfQO=[];
        arrayOfQTF=[];

        if(type==0){
            Actions.QMC();
        }else if(type==1){
            Actions.QO();
        }else{
            Actions.QTF();
        }
    }
    start1 = () => {
        //this.genrateRandoms();
        
        this.set1();  
        /*
        this.getDatastoreQTF(1);*/
    }

    start = () => {
        this.genrateRandoms();
        this.set();  
        /*
        this.getDatastoreQTF(1);*/
    }

    componentDidMount(){


        const maxQMCJSON = SyncStorage.get('maxQMC')
        var max1 = JSON.parse(maxQMCJSON);
        //this.setState({ counter: counter.counter })
        maxQMC=max1.value;

        const maxQOJSON = SyncStorage.get('maxQO')
        var max2 = JSON.parse(maxQOJSON);
        //this.setState({ counter: counter.counter })
        maxQO=max2.value;

        const maxQTFJSON = SyncStorage.get('maxQTF')
        var max3 = JSON.parse(maxQTFJSON);
        //this.setState({ counter: counter.counter })
        maxQTF=max3.value;

        /*this.setState({ maxQMC: 28 })
        this.setState({ maxQO: 6 })
        this.setState({ maxQTF: 4 })*/
            
        //Thread.sleep();

        /*maxQMC=28;
        maxQO=6;
        maxQTF=4;*/

        console.log('tem de ser');
        this.genrateRandoms();
        this.set();

        console.log('entrouentrouentrouentrouentrouentrouentrouentrouentrou');
         return false;
    }




    /*async getNumberOfQuestions(questionType) {
        try {
            // Get items from AsyncStorage
            const usernameValue = await AsyncStorage.getItem('username');
            const verifierValue = await AsyncStorage.getItem('verifier');
            
            // Set current username
            if (usernameValue !== null) {
                console.log(usernameValue);
                this.setState({username: usernameValue});
            }
            
            // Set current verifier
            if (verifierValue !== null) {
                console.log(verifierValue);
                this.setState({verifier: verifierValue});
            }
        } catch (error) {
            // Failed to load data from AsyncStorage
        }
        
        await fetch(appEngineUri + '/rest/question/getLastID?type=' + questionType + 'ID', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : this.state.username,
                'Authorization' : 'Bearer ' + this.state.verifier,
            },
        })
        .then(function(response) {
                console.log(response);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error(response.status);
                }
            })
        .then(data => {
            console.log(data);
            if (questionType == 'QMC')
                this.setState({maxQMC: data});
            else if (questionType == 'QO')
                this.setState({maxQO: data});
            else if (questionType == 'QTF')
                this.setState({maxQTF: data});
        })
        .catch((error) => { alert(error); })
        .done();
    }*/

    mainMenu(){
        Actions.userTrailScreen();
    }

    render() {
        return (
            <Wallpaper>

                <TouchableHighlight style ={styles.submitButtonStart}>
                        <Button onPress={()=> {this.start1()}}            
                        title="Start Quizz"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>

                <TouchableHighlight style ={styles.submitButtonMainPage}>
                        <Button onPress={()=> {this.mainMenu()}}            
                        title="Main Menu"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>
                

            </Wallpaper>
        );
    }
}

const styles = StyleSheet.create({
    submitButtonStart: {
        
        height: 60,
        width:130,
        marginLeft :120,
        marginTop :250,
    },

    submitButtonMainPage: {
        
        height: 60,
        width:130,
        marginLeft :120,
        marginTop :10,
    },
  })



   /*   async getMaxIndexFromDatastore(type){
        if(type == "QMC"){
            //fazer pedido
            //guardar em maxQMC
            maxQMC =23;
/*            
            await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/getLastID?type=QMCID', {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                }
            })
            .then(function(data) {
                console.log(data);
                maxQMC= data;
                //alert(data);
            })
*/

   /*     }else if(type == "QO"){
            maxQO =3;
/*
            await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/getLastID?type=QOID', {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                }
            })
            .then(function(data) {
                console.log(data);
                maxQO= data;
                //alert(data);
            })

*/
     /*   }else{
            maxQTF =1;
/*
            await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/getLastID?type=QTFID', {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                }
            })
            .then(function(data) {
                console.log(data);
                maxQTF= data;
                //alert(data);
            })
*/
 /*       }
    }*/


  /*async getDatastoreQMC(i){
    //fazer pedido
    //guardar CQ


    var Q;
    
    await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQMC1OP/'+ i, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        }
    })
    .then(async (response) => {
        //alert(response);

        //console.log(response.text());
        //Thread.sleep();
        var temp = await response.json();
        this.setState({Q: temp});
        console.log(temp);
        console.log(this.state.Q);
        //alert(response.json());
        //Q = JSON.parse(temp);

        //return temp;
    });
        //alert(Q);
    /*console.log(Q);
    return Q;*/
/*}

/*async getDatastoreQO(i){
    var Q;
    
    await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQO1OP/'+ i, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        }
    })
    .then(async (response) => {
        //alert(response);
        //Thread.sleep();
        //console.log(response.text());
        var temp = await response.json();
        this.setState({Q: temp});
        console.log(temp);
        console.log(this.state.Q);
        //alert(response.json());
        //Q = JSON.parse(temp);

        //return temp;
    });
    /*console.log(Q);
    return Q;*/
    //Thread.sleep();
/*}

/*async getDatastoreQTF(i){
    var Q;
    
    fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQTF1OP/' + i, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        }
        
    })
    .then(async (response) => {
        //alert(response);
        //Thread.sleep();
        //console.log(response.text());
        var temp = await response.json();
        console.log(temp);
        //alert(response.json());
        //Q = JSON.parse(temp);
        this.setState({Q: temp});
        console.log(this.state.Q);
        //return temp;
    });
    //Thread.sleep();
    //return Q;
}
*/

  /**
   * 
   *                 <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.start()}}            
                        title="Load"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight> 
   * 
   * 
   *                 <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.genrateRandoms()}}            
                        title="GET Random Array"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>

                <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.text()}}            
                        title="TEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>
   * 
   */
  /*
  <TouchableHighlight style ={styles.submitButton}>
  <Button onPress={()=> {this.goToQMC()}}            
  title="QMC"
  accessibilityLabel="Learn more about this button"
  color = "#708090"
/> 
</TouchableHighlight> 
<TouchableHighlight style ={styles.submitButton}>
  <Button onPress={()=> {this.goToQO()}}            
  title="QO"
  accessibilityLabel="Learn more about this button"
  color = "#708090"
/> 
</TouchableHighlight> 
<TouchableHighlight style ={styles.submitButton}>
  <Button onPress={()=> {this.goToQTF()}}            
  title="QTF"
  accessibilityLabel="Learn more about this button"
  color = "#708090"
/> 
</TouchableHighlight> 

  <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.clear()}}            
                        title="CLEAR DB"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight> 
                */