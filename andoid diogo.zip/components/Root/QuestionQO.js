import React from "react";

import AsyncStorage from '@react-native-community/async-storage';


//import UserForm from './UserForm';
import Wallpaper from './Wallpaper';


import {targetUri as appEngineUri} from '../../app.json';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';



var questionQMC = {//enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   enunciated:"Qual é a espessura média da crosta continental?",

                   //question: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   question:"escolha a opcao correta",

                   
                   
                   /*optionA: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionB: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionC: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionD: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   */
                   optionA:"7 km",
                   optionB:"35 km",
                   optionC:"1 km",
                   optionD:"100 km",
                   correctOption:"B",
                   id:5
                };

var questionQO = {
                //enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                enunciated: "Ordena as frases de modo a reconstituir a sequência cronológica dos acontecimentos associados a um ciclo oceânico completo (implica o processo de abertura e fecho de um oceano, com a consequente formação de uma cadeia orogénica).",
                question: "Ordena as frases",
                options: {
                    options: ["Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
                                "Início do alargamento de um oceano primitivo.", 
                                "Formação de cadeias montanhosas de colisão.",
                                "Instalação de vulcanismo andesítico em margens continentais ativas.",
                                "Estiramento de crosta continental."]
                },
                byOrder:{
                    byOrder:["option5", "option2", "option1", "option4", "option3"]
                },
                id:""
            };

 //"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
var questionQTF = {
                enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                question: "Classifique como verdadeira ou falsa cada uma das seguintes afirmações, relativas a características da Lua.",
                questionsList: {
                    questions: ["Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",
                                  "Terrae (os continentes) são zonas claras, ricas em minerais félsicos.",
                                  "A erosão tem reduzido o número de crateras de impacto nos mares.",
                                  "Maria (os mares) são zonas escuras, ricas em minerais ferromagnesianos."]
                },
                answersList:{
                    answersList:["T", "T", "F", "T"]
                },
                id:1,
                numberOfQuestions:4
            };


var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 5000) break;
        }
        
    }
    };




var optionsByOrder= [];
var optionsByOrderVal= [];

var nexType;
var counterInt=0;

var CQ;

export default class QuestionQO extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            option1Order:'1',
            option2Order:'2',
            option3Order:'3',
            option4Order:'4',
            option5Order:'5',

            enunciated: '',
            question:'',
            options:[],
            byOrder:[],

            counter:'',

            username: '',
            verifier: '',
        };
    
    }

    componentWillMount(){

        const counterJSON = SyncStorage.get('counter')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })
        counterInt = counter.counter;

        const CQJSON = SyncStorage.get('CQ' + counterInt)
        var CQ = JSON.parse(CQJSON);

        var questionQO = CQ.question;
        //alert(questionQO.question);

        //alert(counterInt);
        //alert(CQ);

        /*const q = SyncStorage.get('QO');
        var questionQO = JSON.parse(q);
        */

        this.setState({ enunciated: questionQO.enunciated })
        this.setState({ question: questionQO.question })
        var optionsFromDB = questionQO.options.options;
        var byOrderFromDB = questionQO.byOrder.byOrder;

        this.setState({ options: optionsFromDB })
        this.setState({ byOrder: byOrderFromDB })


        return false;
    }
    


    componentDidMount(){


        if(counterInt==10){
            return false;
        }

        var i = counterInt +1;
        var CTJSON = SyncStorage.get('CT'+ i);
        var CT = JSON.parse(CTJSON);
        nexType = CT.type;
        //alert(CTJSON);
        var arrayOfIds;

        if(nexType==0){
            var arrayJSON = SyncStorage.get('arrayQMC');
            arrayOfIds = JSON.parse(arrayJSON);
        }else if(nexType==1){
            var arrayJSON = SyncStorage.get('arrayQO');
            arrayOfIds = JSON.parse(arrayJSON);
        }else{
            var arrayJSON = SyncStorage.get('arrayQTF');
            arrayOfIds = JSON.parse(arrayJSON);
        }

        var nextId = arrayOfIds.array[counterInt];

        //fazer get da Q ha DS (nextType, nextId)
        //Set na SS da Q
        
        if(nexType==0){
            //this.getDatastoreQMC(nextId);
            this.getQuestion('QMC', nextId);
        }else if(nexType==1){
            //this.getDatastoreQO(nextId);
            this.getQuestion('QO', nextId);
        }else{
            //this.getDatastoreQTF(nextId);
            this.getQuestion('QTF', nextId);
        }

    }
    CDM(){
        var i = counterInt +1;
        CQ = {counter : i, question: this.state.Q};
        SyncStorage.set('CQ' + i, JSON.stringify(CQ));
    }


    async getQuestion(questionType, questionId) {
        try {
            // Get items from AsyncStorage
            const usernameValue = await AsyncStorage.getItem('username');
            const verifierValue = await AsyncStorage.getItem('verifier');
            
            // Set current username
            if (usernameValue !== null) {
                console.log(usernameValue);
                this.setState({username: usernameValue});
            }
            
            // Set current verifier
            if (verifierValue !== null) {
                console.log(verifierValue);
                this.setState({verifier: verifierValue});
            }
        } catch (error) {
            // Failed to load data from AsyncStorage
        }
        
        await fetch(appEngineUri + '/rest/question/OPG' + questionType + '1OP/' + questionId, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : this.state.username,
                'Authorization' : 'Bearer ' + this.state.verifier,
            },
        })
        .then(function(response) {
                console.log(response);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error(response.status);
                }
            })
        .then(data => {
            console.log(data);
            //var temp = await response.json();
            this.setState({Q: data});
            //this.setState({question: data});
        })
        .catch((error) => { alert(error); })
        .done();
    }


    enuncitedShow(){
        return this.state.enunciated;
    }

    questionShow(){
        return this.state.question;
    }

    optionShow(x){
        return this.state.options[x];
    }

    validateQs(){
        var bol1= false;
        var bol2= false;
        var bol3= false;
        var bol4= false;
        var bol5= false;

        if(this.state.byOrder[0] == optionsByOrder[0])
            bol1=true;

        if(this.state.byOrder[1] == optionsByOrder[1])
            bol2=true;

        if(this.state.byOrder[2] == optionsByOrder[2])
            bol3=true;

        if(this.state.byOrder[3] == optionsByOrder[3])
            bol4=true;

        if(this.state.byOrder[4] == optionsByOrder[4])
            bol5=true;

        return bol1 && bol2 && bol3 && bol4 && bol5;
    }

    setOrder(option, optionOrder){

        optionsByOrder[optionOrder-1]=option
         
    }

    setOrderVal(option, optionOrder){

        optionsByOrderVal[optionOrder-1]=option
         
    }

    optionByOrderJoin(option1Order, option2Order, option3Order, option4Order, option5Order){



        this.setOrderVal("option1", option1Order);
        this.setOrderVal("option2", option2Order);
        this.setOrderVal("option3", option3Order);
        this.setOrderVal("option4", option4Order);
        this.setOrderVal("option5", option5Order);
        


        var byOrder={byOrder:[optionsByOrderVal[0], optionsByOrderVal[1], optionsByOrderVal[2], optionsByOrderVal[3], optionsByOrderVal[4]]};
        //alert(byOrder.byOrder);
        return byOrder;
    };

    getCounter(){
        return this.state.counter;
    }

    formulateQ(){

        if((this.state.option1Order <1 || this.state.option1Order > 5 )
            ||(this.state.option2Order <1 || this.state.option2Order > 5)
            ||(this.state.option3Order <1 || this.state.option3Order > 5)
            ||(this.state.option4Order <1 || this.state.option4Order > 5)
            ||(this.state.option5Order <1 || this.state.option5Order > 5)){
                Alert.alert("invalid numbers");
                return false;
            }

        var byOrder = this.optionByOrderJoin(this.state.option1Order, this.state.option2Order,
            this.state.option3Order, this.state.option4Order, this.state.option5Order);

            //alert(byOrder.byOrder);
        for(var i = 0; i < byOrder.byOrder.length;i++){
            /*for(var j = 0; j < byOrder.byOrder.length;j++)
                if(byOrder.byOrder[i]==byOrder.byOrder[j] && i!=j){
                    Alert.alert("not all diferent");
                    return false;
                }*/
                if(typeof byOrder.byOrder[i] == "undefined") {
                    Alert.alert("not all diferent");
                    return false;
                }
        }

        this.setOrder("option1", this.state.option1Order);
        this.setOrder("option2", this.state.option2Order);
        this.setOrder("option3", this.state.option3Order);
        this.setOrder("option4", this.state.option4Order);
        this.setOrder("option5", this.state.option5Order);
        
        return true;
    }

    setCounter(){

        //var tempCounterString = this.getCounter();
        var number = counterInt;
        number++;
        var counter = {counter : number};

        SyncStorage.set('counter', JSON.stringify(counter));


    }

    nextQuestion(){

        this.CDM();

        this.setCounter();

        if(!this.formulateQ())
            return false;


        var bol = this.validateQs()
        var answer = {answer : bol};
        SyncStorage.set('answer' + counterInt, JSON.stringify(answer));
        //verificar para finish
        //alert(counterInt);
        /*if(counterInt==10){
            Actions.FinishQuizz();
        }*/
        
        var number = counterInt;
        var number1 = number.toString();

        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.QMC();
        }else if(nexType==1){
            Actions.QO();
        }else{
            Actions.QTF();
        }
    }

    skip(){


        this.CDM();

        this.setCounter();

        var answer = {answer : false};
        SyncStorage.set('answer' + counterInt, JSON.stringify(answer));

        //verificar para finish
        /*if(counterInt==10){
            Actions.FinishQuizz();
        }*/

        var number = counterInt;
        var number1 = number.toString();


        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }


        if(nexType==0){
            Actions.QMC();
        }else if(nexType==1){
            Actions.QO();
        }else{
            Actions.QTF();
        }
    }
    contentSizeChange = ({nativeEvent:event}) => {
        this.setState({ textAreaHeight: event.contentSize.height });
    };
    render() {

        const {textAreaHeight } = this.state;

        return (
            <Wallpaper>

                <Text style={styles.textEnunciated}>Question nº {this.getCounter()}</Text>
                <Text style={styles.textEnunciated}>Enunciated</Text>
                <View style={styles.textViewEnunciatedMain}>
                    
                    <ScrollView /*style={styles.textEnunciatedMain}*/>  
                        
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.enuncitedShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                <Text style={styles.textEnunciated}>Question</Text>
                <View style={styles.textViewQuestionMain} >
                    <ScrollView>
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.questionShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>

                <ScrollView nestedScrollEnabled = {true}>
                
                    
                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 1</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option1Order => this.setState({ option1Order })}
                                value={this.state.option1Order}
                                maxLength={1}  //setting limit of input
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(0)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 2</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option2Order => this.setState({ option2Order })}
                                value={this.state.option2Order}
                                maxLength={1}  //setting limit of input
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(1)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 3</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option3Order => this.setState({ option3Order })}
                                value={this.state.option3Order}
                                maxLength={1}  //setting limit of input
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(2)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>


                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 4</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option4Order => this.setState({ option4Order })}
                                value={this.state.option4Order}
                                maxLength={1}  //setting limit of input
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(3)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    
                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 5</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option5Order => this.setState({ option5Order })}
                                value={this.state.option5Order}
                                maxLength={1}  //setting limit of input
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(4)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>
                    <TouchableHighlight style ={styles.skipButton}>
                        <Button onPress={()=> {this.skip()}}            
                        title="SKIP"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 
                    <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.nextQuestion()}}            
                        title="NEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight>
                    <Text> </Text>
                    <Text> </Text> 
                </ScrollView>
            </Wallpaper>
        );
    }
}


const styles = StyleSheet.create({

    textViewEnunciatedMain: {
        maxHeight: 160,
        borderWidth: 3,
        borderColor: 'black',
     },

     textViewQuestionMain: {
        maxHeight: 100,
        borderWidth: 3,
        borderColor: 'black',
     },

    textEnunciated: {
        marginLeft: 10,
        fontSize: 18,
        color: 'white',
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textAreaEnunciated: {
        fontSize: 15,
        color: 'black',
        backgroundColor: 'silver',
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textOption: {
        marginLeft: 10,
        fontSize: 16,
        color: Colors.orange500,
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textViewOptionMain: {
        // height: 'auto',

     },

     radioButtons: {
        //marginTop:35,
        borderColor: 'black',
        borderWidth: 3,
        backgroundColor: 'silver',
        width:30,
        height: 40,
        marginTop:0,
     },

     numberInput: {
        marginTop: -3,
        width:100,
     },

    textViewOption: {
        maxHeight: 160,
        borderColor: 'black',
        marginTop:-40,
        // height: 'auto',
         marginLeft: 35,
        // borderColor: '#c0c0c0',
         borderWidth: 3,
         padding: 0,
     },



     textAreaOption: {
        backgroundColor: 'silver',
        fontSize: 15,
        color: 'black',
        height: 100,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },
    skipButton: {
        
        height: 40,
        width:100,
        marginLeft :70,
        marginTop :20,
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :200,
        marginTop :-40,
    },
  })



      /*async getDatastoreQMC(i){
        //fazer pedido
        //guardar CQ


        var Q;
        
        await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQMC1OP/'+ i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({Q: temp});
            console.log(temp);
            console.log(this.state.Q);
        });
    }

    async getDatastoreQO(i){
        var Q;
        
        await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQO1OP/'+ i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({Q: temp});
            console.log(temp);
            console.log(this.state.Q);
        });
    }

    async getDatastoreQTF(i){
        var Q;
        
        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQTF1OP/' + i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
            
        })
        .then(async (response) => {
            var temp = await response.json();
            console.log(temp);
            this.setState({Q: temp});
            console.log(this.state.Q);
        });
    }*/




  /***
 * 
 * <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionShow(0)}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
 */


/***
 *                     <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option 2</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option2Order => this.setState({ option2Order })}
                                value={this.state.option2Order}
                                maxLength={1}  //setting limit of input
                            />

                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionShow(1)}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option 3</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option3Order => this.setState({ option3Order })}
                                value={this.state.option3Order}
                                maxLength={1}  //setting limit of input
                            />

                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionShow(2)}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option 4</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option4Order => this.setState({ option4Order })}
                                value={this.state.option4Order}
                                maxLength={1}  //setting limit of input
                            />

                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionShow(3)}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option 5</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option5Order => this.setState({ option5Order })}
                                value={this.state.option5Order}
                                maxLength={1}  //setting limit of input
                            />

                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionShow(4)}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>
 * 
 * 
 */



/**
 * 
 *                         <NumericInput 
                            value={this.state.option1Order} 
                            onChange={option1Order => this.setState({ option1Order }) } 
                            type='up-down'/>
 * <NumericInput value={this.state.option1Order} onChange={option1Order => this.setState({ option1Order }) } type='up-down'/>
 * 
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={option1Order => this.setState({ option1Order })}
                                value={this.state.option1Order}
                                maxLength={5}  //setting limit of input
                            /> 
 */

/**
 *                                 style={styles.numberInput}
                                keyboardType='numeric'
                                onChangeText={this.option1OrderChange}
                                value={this.state.option1Order}
                                maxLength={5}  //setting limit of input
 */
/**<Button
                    style={styles.submitButton}
                    onPress={()=> {this.radioShow()}}
                    title="Learn More"
                /> */
/*para radio button
value="D"
status={checked === 'second' ? 'checked' : 'unchecked'}
          onPress={() => { this.setState({ checked: 'second' }); }}*/