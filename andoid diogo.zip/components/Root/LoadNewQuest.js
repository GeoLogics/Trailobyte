//copiar codigo loginScreen e adaptar
//adicionar ao Root.js
//se tiver alguma duvida verificar zip "src Diogo para o final com as cenas do joao"
//e
//se tiver alguma duvida verificar zip "src diogo com QO validate old look"
//estao ambos no ambiente de trabalho


import React from "react";

import AsyncStorage from '@react-native-community/async-storage';


//import UserForm from './UserForm';
import Wallpaper from './Wallpaper';


import {targetUri as appEngineUri} from '../../app.json';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';


import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';



var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 1200) break;
        }
        
    }
};


export default class Quizz extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            Q: null,

            username: '',
            verifier: '',

            maxQMC: 0,
            maxQO: 0,
            maxQTF: 0,
        };
    
    }

    componentWillMount(){
        this.getNumberOfQuestions('QMC');
        this.getNumberOfQuestions('QO');
        this.getNumberOfQuestions('QTF');
    }

    async getNumberOfQuestions(questionType) {
        try {
            // Get items from AsyncStorage
            const usernameValue = await AsyncStorage.getItem('username');
            const verifierValue = await AsyncStorage.getItem('verifier');
            
            // Set current username
            if (usernameValue !== null) {
                console.log(usernameValue);
                this.setState({username: usernameValue});
            }
            
            // Set current verifier
            if (verifierValue !== null) {
                console.log(verifierValue);
                this.setState({verifier: verifierValue});
            }
        } catch (error) {
            // Failed to load data from AsyncStorage
        }
        
        await fetch(appEngineUri + '/rest/question/getLastID?type=' + questionType + 'ID', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : this.state.username,
                'Authorization' : 'Bearer ' + this.state.verifier,
            },
        })
        .then(function(response) {
                //console.log(response);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error(response.status);
                }
            })
        .then(data => {
            console.log(data);
            if (questionType == 'QMC')
                this.setState({maxQMC: data});
            else if (questionType == 'QO')
                this.setState({maxQO: data});
            else if (questionType == 'QTF')
                this.setState({maxQTF: data});
        })
        .catch((error) => { alert(error); })
        .done();
    }

    loadNewQuestions(){
        var maxQMC = {value: this.state.maxQMC};
        SyncStorage.set('maxQMC', JSON.stringify(maxQMC));

        var maxQO = {value: this.state.maxQO};
        SyncStorage.set('maxQO', JSON.stringify(maxQO));

        var maxQTF = {value: this.state.maxQTF};
        SyncStorage.set('maxQTF', JSON.stringify(maxQTF));

        console.log('passou');

        Actions.Quizz();
    }

    goTo(){

        Actions.Quizz();
    }

    render() {
        return (
            <Wallpaper>

                

                <TouchableHighlight style ={styles.submitButtonStart}>
                        <Button onPress={()=> {this.loadNewQuestions()}}            
                        title="Load New Questions"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>
                

            </Wallpaper>
        );
    }
}

const styles = StyleSheet.create({
    submitButtonStart: {
        
        height: 60,
        width:130,
        marginLeft :120,
        marginTop :250,
    },
  })

  /*
  <TouchableHighlight style ={styles.submitButtonStart}>
                        <Button onPress={()=> {this.goTo()}}            
                        title="Start Quizz"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight>
  
  */