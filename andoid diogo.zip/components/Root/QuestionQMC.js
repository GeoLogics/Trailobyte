//copiar codigo loginScreen e adaptar
//adicionar ao Root.js
//se tiver alguma duvida verificar zip "src Diogo para o final com as cenas do joao"
//e
//se tiver alguma duvida verificar zip "src diogo com QO validate old look"
//estao ambos no ambiente de trabalho


import React from "react";
import PropTypes from 'prop-types';
import AsyncStorage from '@react-native-community/async-storage';


//import UserForm from './UserForm';
import Wallpaper from './Wallpaper';


import {targetUri as appEngineUri} from '../../app.json';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';

var questionQMC = {//enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   enunciated:"Qual é a espessura média da crosta continental?",

                   //question: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   question:"escolha a opcao correta",

                   
                   
                   /*optionA: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionB: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionC: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionD: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   */
                   optionA:"7 km",
                   optionB:"35 km",
                   optionC:"1 km",
                   optionD:"100 km",
                   correctOption:"B",
                   id:5
                };

var questionQO = {
                //enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                enunciated: "Ordena as frases de modo a reconstituir a sequência cronológica dos acontecimentos associados a um ciclo oceânico completo (implica o processo de abertura e fecho de um oceano, com a consequente formação de uma cadeia orogénica).",
                question: "Ordena as frases",
                options: {
                    options: ["Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
                                "Início do alargamento de um oceano primitivo.", 
                                "Formação de cadeias montanhosas de colisão.",
                                "Instalação de vulcanismo andesítico em margens continentais ativas.",
                                "Estiramento de crosta continental."]
                },
                byOrder:{
                    byOrder:["option5", "option2", "option1", "option4", "option3"]
                },
                id:""
            };

 //"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
var questionQTF = {
                enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                question: "Classifique como verdadeira ou falsa cada uma das seguintes afirmações, relativas a características da Lua.",
                questionsList: {
                    questions: ["Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",
                                  "Terrae (os continentes) são zonas claras, ricas em minerais félsicos.",
                                  "A erosão tem reduzido o número de crateras de impacto nos mares.",
                                  "Maria (os mares) são zonas escuras, ricas em minerais ferromagnesianos."]
                },
                answersList:{
                    answersList:["T", "T", "F", "T"]
                },
                id:1,
                numberOfQuestions:4
            };

var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 5000) break;
        }
        
    }
};

var CQ;
var nexType;
var counterInt=0;
export default class QuestionQMC extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            selectedOpc:'',

            enunciated: '',
            question:'',
            optionA:'',
            optionB:'',
            optionC:'',
            optionD:'',
            correctOption:'',

            counter:0,

            Q:null,

            username: '',
            verifier: '',
        };
    
    }
//meter isto no construtor
    componentWillMount(){

        const counterJSON = SyncStorage.get('counter')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })
        counterInt = counter.counter;
        
        const CQJSON = SyncStorage.get('CQ' + counterInt)
        var CQ = JSON.parse(CQJSON);

        var questionQMC = CQ.question;
        //alert(questionQMC.question);
        //alert(counterInt);
        //alert(CQ);
        
        /*const q = SyncStorage.get('QMC');
        var questionQMC = JSON.parse(q);*/

        
        this.setState({ enunciated: questionQMC.enunciated })
        this.setState({ question: questionQMC.question })
        this.setState({ optionA: questionQMC.optionA })
        this.setState({ optionB: questionQMC.optionB })
        this.setState({ optionC: questionQMC.optionC })
        this.setState({ optionD: questionQMC.optionD })
        this.setState({ correctOption: questionQMC.correctOption })

        return false;
    }

    componentDidMount(){

        if(counterInt==10){
            return false;
        }

        //alert("entrou no DID MOUNT");
        var i = counterInt +1;
        var CTJSON = SyncStorage.get('CT'+ i);

        //alert(CTJSON);
        var CT = JSON.parse(CTJSON);

        nexType = CT.type;

        //var CTJSON = SyncStorage.get('CT'+ i);
        var arrayOfIds;

        if(nexType==0){
            var arrayJSON = SyncStorage.get('arrayQMC');
            arrayOfIds = JSON.parse(arrayJSON);
        }else if(nexType==1){
            var arrayJSON = SyncStorage.get('arrayQO');
            arrayOfIds = JSON.parse(arrayJSON);
        }else{
            var arrayJSON = SyncStorage.get('arrayQTF');
            arrayOfIds = JSON.parse(arrayJSON);
        }

        var nextId = arrayOfIds.array[counterInt];

        //fazer get da Q ha DS (nextType, nextId)
        //Set na SS da Q

        

        
        if(nexType==0){
            //this.getDatastoreQMC(nextId);
            this.getQuestion('QMC', nextId);
            //CQ = {counter : i, question: Quest};
/*
            var CQ = {counter : i, question: questionQMC};
            SyncStorage.set('CQ' + i, JSON.stringify(CQ));*/
        }else if(nexType==1){
            //this.getDatastoreQO(nextId);
            this.getQuestion('QO', nextId);
            //CQ = {counter : i, question: Quest};
/*
            var CQ = {counter : i, question: questionQO};
            SyncStorage.set('CQ' + i, JSON.stringify(CQ));*/
        }else{
            //this.getDatastoreQTF(nextId);
            this.getQuestion('QTF', nextId);
            //CQ = {counter : i, question: Quest};
/*
            var CQ = {counter : i, question: questionQTF};
            SyncStorage.set('CQ' + i, JSON.stringify(CQ));*/
        }

    }

    CDM(){
        var i = counterInt +1;
        CQ = {counter : i, question: this.state.Q};
        SyncStorage.set('CQ' + i, JSON.stringify(CQ));
    }

    async getQuestion(questionType, questionId) {
        try {
            // Get items from AsyncStorage
            const usernameValue = await AsyncStorage.getItem('username');
            const verifierValue = await AsyncStorage.getItem('verifier');
            
            // Set current username
            if (usernameValue !== null) {
                console.log(usernameValue);
                this.setState({username: usernameValue});
            }
            
            // Set current verifier
            if (verifierValue !== null) {
                console.log(verifierValue);
                this.setState({verifier: verifierValue});
            }
        } catch (error) {
            // Failed to load data from AsyncStorage
        }
        
        await fetch(appEngineUri + '/rest/question/OPG' + questionType + '1OP/' + questionId, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : this.state.username,
                'Authorization' : 'Bearer ' + this.state.verifier,
            },
        })
        .then(function(response) {
                console.log(response);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error(response.status);
                }
            })
        .then(data => {
            console.log(data);
            //var temp = await response.json();
            this.setState({Q: data});
            //this.setState({question: data});
        })
        .catch((error) => { alert(error); })
        .done();
    }



    enuncitedShow(){
        return this.state.enunciated;

    }

    questionShow(){
        return this.state.question;
    }

    optionAShow(){
        return this.state.optionA;
    }

    optionBShow(){
        return this.state.optionB;
    }

    optionCShow(){
        return this.state.optionC;
    }

    optionDShow(){
        return this.state.optionD;
    }
    
    validateQ(){
        
        if(this.state.selectedOpc == this.state.correctOption)
            return true;
        
        return false;
        

    };


    getCounter(){
        return this.state.counter;
    }

    setCounter(){

        //var tempCounterString = this.getCounter();
        var number = counterInt;
        number++;
        var counter = {counter : number};

        SyncStorage.set('counter', JSON.stringify(counter));


    }

    nextQuestion(){

        this.CDM();

        this.setCounter();

        var cenas =this.validateQ();
        var answer = {answer : cenas};

        
        //Alert.alert(this.state.counter);

        SyncStorage.set('answer' + counterInt, JSON.stringify(answer));

        //verificar para finish
        /*alert(counterInt);
        Thread.sleep();*/

        var number = counterInt;
        var number1 = number.toString();
        //alert(number1.localeCompare("10"));
        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.QMC();
        }else if(nexType==1){
            Actions.QO();
        }else{
            Actions.QTF();
        }
        
    }

    skip(){

        this.CDM();

        this.setCounter();

        var answer = {answer : false};
        SyncStorage.set('answer' + counterInt, JSON.stringify(answer));
//verificar para finish
/*
        if(counterInt==10){
            Actions.FinishQuizz();
        }*/


        var number = counterInt;
        var number1 = number.toString();
        //alert(number1.localeCompare("10"));
        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.QMC();
        }else if(nexType==1){
            Actions.QO();
        }else{
            Actions.QTF();
        }
    }

   radioShow(){
        //this.setState({ checked: va });
        if(this.validateQ()== true){
            Alert.alert("Your awnser is correct");
        }
        else{
            Alert.alert("Please try again");
        }
        
    }

    _onContentSizeChange = ({nativeEvent:event}) => {
        this.setState({ textAreaHeight: event.contentSize.height });
    };

    render() {

        const { text, textAreaHeight } = this.state;

        return (
            <Wallpaper>
                <Text style={styles.textEnunciated}>Question nº {this.getCounter()}</Text>
                <Text style={styles.textEnunciated}>Enunciated</Text>
                <View style={styles.textViewEnunciatedMain}>
                    
                    <ScrollView /*style={styles.textEnunciatedMain}*/>  
                        
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.enuncitedShow()}
                            //onChangeText={text => this.setState({ text })}
                            onContentSizeChange={this._onContentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                <Text style={styles.textEnunciated}>Question</Text>
                <View style={styles.textViewQuestionMain} >
                    <ScrollView>
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.questionShow()}
                            //onChangeText={text => this.setState({ text })}
                            onContentSizeChange={this._onContentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                
                <ScrollView nestedScrollEnabled = {true}>
                    <RadioButton.Group
                        onValueChange={selectedOpc => this.setState({ selectedOpc })}
                        value={this.state.selectedOpc}
                    >
                
                    
                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option A</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "A" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionAShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option B</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "B" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionBShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option C</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "C" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionCShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option D</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "D" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionDShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>
                    
                    
                    </RadioButton.Group>

                    <TouchableHighlight style ={styles.skipButton}>
                        <Button onPress={()=> {this.skip()}}            
                        title="SKIP"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 

                    <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.nextQuestion()}}            
                        title="NEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 
                    <Text> </Text>
                    <Text> </Text>
                </ScrollView>
            </Wallpaper>
        );
    }
}

/**<Button
                    style={styles.submitButton}
                    onPress={()=> {this.radioShow()}}
                    title="Learn More"
                /> */
/*para radio button
value="D"
status={checked === 'second' ? 'checked' : 'unchecked'}
          onPress={() => { this.setState({ checked: 'second' }); }}*/

const styles = StyleSheet.create({
    textViewEnunciatedMain: {
        maxHeight: 160,
        borderWidth: 3,
        borderColor: 'black',
     },

     textViewQuestionMain: {
        maxHeight: 100,
        borderWidth: 3,
        borderColor: 'black',
     },

    textEnunciated: {
        marginLeft: 10,
        fontSize: 18,
        color: 'white',
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textAreaEnunciated: {
        fontSize: 15,
        color: 'black',
        backgroundColor: 'silver',
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },


    textOption: {
        marginLeft: 10,
        fontSize: 16,
        color: Colors.orange500,
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textViewOptionMain: {
     },

    textViewOption: {
        maxHeight: 160,
        borderColor: 'black',
        marginTop:-42,
         marginLeft: 35,
         borderWidth: 3,
         padding: 0,
     },

     radioButtons: {
        marginTop:10,
     },

    skipButton: {
        
        height: 40,
        width:100,
        marginLeft :70,
        marginTop :20,
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :200,
        marginTop :-40,
    },
  })


      /*textEnunciatedMain: {
        // height: 'auto',
         height: 300,
         borderColor: 'black',
         borderWidth: 3,
         padding: 0,
         //borderBottomWidth: 3,
     },*/
/*
    textViewEnunciated: {
       // height: 'auto',
        height: 2200,
        borderColor: 'black',
        borderWidth: 3,
        padding: 0,
    },*/
     /*
    textViewQuestionMain:{
        height: 86,
        borderColor: 'black',
        borderWidth: 3,
        padding: 0,
    },*/
/*
    textAreaQuestion: {
        backgroundColor: 'silver',
        fontSize: 15,
        color: 'black',
        height: 80,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },*/
     
          /*textAreaOption: {
        backgroundColor: 'silver',
        fontSize: 15,
        color: 'black',
        height: 100,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },*/




        /*async getDatastoreQMC(i){
        //fazer pedido
        //guardar CQ


        var Q;
        
        await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQMC1OP/'+ i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({Q: temp});
            console.log(temp);
            console.log(this.state.Q);
        });
    }

    async getDatastoreQO(i){
        var Q;
        
        await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQO1OP/'+ i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({Q: temp});
            console.log(temp);
            console.log(this.state.Q);
        });
    }

    async getDatastoreQTF(i){
        var Q;
        
        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQTF1OP/' + i, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            }
            
        })
        .then(async (response) => {
            var temp = await response.json();
            console.log(temp);
            this.setState({Q: temp});
            console.log(this.state.Q);
        });
    }*/


/***
 * 
 * 
 * <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionAShow()}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
 */


/***
 * 
 * 
 * 
 * <TextInput
                        style={styles.textAreaQuestion}
                        underlineColorAndroid="transparent"
                        value={this.questionShow()}
                        numberOfLines={10}
                        multiline={true}
                        editable = {false}
                    />
 */


  /**
   * Fazia parte do enunciated
   * <View style={styles.textViewEnunciated} >
                            <TextInput
                                style={styles.textAreaEnunciated}
                                underlineColorAndroid="transparent"
                                value={this.enuncitedShow()}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
   */


   /*****
    * 
    * 
    * 
    * 
    * <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option B</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "B" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionBShow()}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>

                    
                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option C</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "C" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionCShow()}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>

                    
                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option D</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                            value = "D" 
                            color={Colors.orange100} 
                            uncheckedColor={Colors.orange100}
                            />
                        </View>
                        <View style={styles.textViewOption} >

                            <TextInput
                                style={styles.textAreaOption}
                                underlineColorAndroid="transparent"
                                value={this.optionDShow()}
                                numberOfLines={10}
                                multiline={true}
                                editable = {false}
                            />
                        </View>
                    </View>
    */