import React from "react";
import Wallpaper from './Wallpaper';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';


var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 5000) break;
        }
        
    }
};

var CQ;
var nexType;
var counterInt=0;
export default class QuestionQMC extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            selectedOpc:'',

            enunciated: '',
            question:'',
            optionA:'',
            optionB:'',
            optionC:'',
            optionD:'',
            correctOption:'',

            counter:0,

            Q:null,

            username: '',
            verifier: '',
        };
    
    }
//meter isto no construtor
    componentWillMount(){

        const counterJSON = SyncStorage.get('CS')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })
        counterInt = counter.counter;
        
        const CQJSON = SyncStorage.get('CQ' + counterInt)
        var CQ = JSON.parse(CQJSON);

        var questionQMC = CQ.question;

        console.log('counterInt:'+counterInt);

        this.setState({ enunciated: questionQMC.enunciated })
        this.setState({ question: questionQMC.question })
        this.setState({ optionA: questionQMC.optionA })
        this.setState({ optionB: questionQMC.optionB })
        this.setState({ optionC: questionQMC.optionC })
        this.setState({ optionD: questionQMC.optionD })
        this.setState({ correctOption: questionQMC.correctOption })

        return false;
    }

    componentDidMount(){

        if(counterInt==10){
            return false;
        }

        var i = counterInt +1;
        var CTJSON = SyncStorage.get('CT'+ i);
        var CT = JSON.parse(CTJSON);
        nexType = CT.type;

        this.CDM();
    }

    CDM(){
        var i = counterInt +1;
        var CS = {counter : i};
        SyncStorage.set('CS', JSON.stringify(CS));
    }


    enuncitedShow(){
        return this.state.enunciated;

    }

    questionShow(){
        return this.state.question;
    }

    optionAShow(){
        return this.state.optionA;
    }

    optionBShow(){
        return this.state.optionB;
    }

    optionCShow(){
        return this.state.optionC;
    }

    optionDShow(){
        return this.state.optionD;
    }
    

    skip(){
        Actions.FinishQuizz();
    }


    nextQuestion(){

        var number = counterInt;
        var number1 = number.toString();
        //alert(number1.localeCompare("10"));
        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.SOLQMC();
        }else if(nexType==1){
            Actions.SOLQO();
        }else{
            Actions.SOLQTF();
        }
        
    }

   radioShow(valueOf){
        if(this.state.correctOption == valueOf){
            return 'checked';
        }else{
            return 'unchecked';
        }
        
    }

    getCounter(){
        return this.state.counter;
    }

    _onContentSizeChange = ({nativeEvent:event}) => {
        this.setState({ textAreaHeight: event.contentSize.height });
    };

    render() {

        const { text, textAreaHeight } = this.state;

        return (
            <Wallpaper>
                <Text style={styles.textEnunciated}>Solution nº {this.getCounter()}</Text>
                <Text style={styles.textEnunciated}>Enunciated</Text>
                <View style={styles.textViewEnunciatedMain}>
                    
                    <ScrollView /*style={styles.textEnunciatedMain}*/>  
                        
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.enuncitedShow()}
                            //onChangeText={text => this.setState({ text })}
                            onContentSizeChange={this._onContentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                <Text style={styles.textEnunciated}>Question</Text>
                <View style={styles.textViewQuestionMain} >
                    <ScrollView>
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.questionShow()}
                            //onChangeText={text => this.setState({ text })}
                            onContentSizeChange={this._onContentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                
                <ScrollView nestedScrollEnabled = {true}>
                    <RadioButton.Group
                        //onValueChange={selectedOpc => this.setState({ selectedOpc })}
                        //value={this.state.selectedOpc}
                        
                    >
                
                    
                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option A</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "A" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                                status={this.radioShow("A")}
                                //disabled={true}
                                //style={styles.radio}
                                
                                
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionAShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option B</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "B" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                                status={this.radioShow("B")}
                                //disabled={true}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionBShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option C</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "C" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                                status={this.radioShow("C")}
                                //disabled={true}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionCShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>

                    <View style={styles.textViewOptionMain} >
                        <Text style={styles.textOption}>Option D</Text>
                        <View style={styles.radioButtons} >
                            <RadioButton 
                                value = "D" 
                                color={Colors.orange100} 
                                uncheckedColor={Colors.orange100}
                                status={this.radioShow("D")}
                                //disabled={true}
                            />
                        </View>
                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionDShow()}
                                    //onChangeText={text => this.setState({ text })}
                                    onContentSizeChange={this._onContentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>
                    </View>
                    
                    
                    </RadioButton.Group>

                    <TouchableHighlight style ={styles.skipButton}>
                        <Button onPress={()=> {this.skip()}}            
                        title="SKIP"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 

                    <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.nextQuestion()}}            
                        title="NEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 
                    <Text> </Text>
                    <Text> </Text>
                </ScrollView>
            </Wallpaper>
        );
    }
}


const styles = StyleSheet.create({
    textViewEnunciatedMain: {
        maxHeight: 160,
        borderWidth: 3,
        borderColor: 'black',
     },

     textViewQuestionMain: {
        maxHeight: 100,
        borderWidth: 3,
        borderColor: 'black',
     },

    textEnunciated: {
        marginLeft: 10,
        fontSize: 18,
        color: 'white',
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textAreaEnunciated: {
        fontSize: 15,
        color: 'black',
        backgroundColor: 'silver',
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },


    textOption: {
        marginLeft: 10,
        fontSize: 16,
        color: Colors.orange500,
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textViewOptionMain: {
     },

    textViewOption: {
        maxHeight: 160,
        borderColor: 'black',
        marginTop:-42,
         marginLeft: 35,
         borderWidth: 3,
         padding: 0,
     },

     radioButtons: {
        marginTop:10,
     },

     radio: {
        color: Colors.orange100,
     },

    skipButton: {
        
        height: 40,
        width:100,
        marginLeft :70,
        marginTop :20,
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :200,
        marginTop :-40,
    },
  })

