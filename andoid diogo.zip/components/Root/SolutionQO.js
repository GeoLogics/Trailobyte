import React from "react";

import Wallpaper from './Wallpaper';

import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';



var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 5000) break;
        }
        
    }
    };




var optionsByOrder= [];

var nexType;
var counterInt=0;

export default class QuestionQO extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            /*option1Order:'1',
            option2Order:'2',
            option3Order:'3',
            option4Order:'4',
            option5Order:'5',*/

            enunciated: '',
            question:'',
            options:[],
            byOrder:[],

            counter:'',

        };
    
    }

    componentWillMount(){

        const counterJSON = SyncStorage.get('CS')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })
        counterInt = counter.counter;

        const CQJSON = SyncStorage.get('CQ' + counterInt)
        var CQ = JSON.parse(CQJSON);

        var questionQO = CQ.question;


        this.setState({ enunciated: questionQO.enunciated })
        this.setState({ question: questionQO.question })
        var optionsFromDB = questionQO.options.options;
        var byOrderFromDB = questionQO.byOrder.byOrder;

        this.setState({ options: optionsFromDB })
        this.setState({ byOrder: byOrderFromDB })


        return false;
    }
    

    getCorrectOrder(j){

        console.log('byOrder: '+this.state.byOrder[j]);
        var cenas = this.state.byOrder[j];
        var cenas1= cenas.split("n");
        var cenas2 = cenas1[1];
        console.log(cenas2);
        return cenas2;
        //return this.state.byOrder[j];
        
      
    }


    componentDidMount(){



        if(counterInt==10){
            return false;
        }

        var i = counterInt +1;
        var CTJSON = SyncStorage.get('CT'+ i);
        var CT = JSON.parse(CTJSON);
        nexType = CT.type;

        this.CDM();
    }

    CDM(){
        var i = counterInt +1;
        var CS = {counter : i};
        SyncStorage.set('CS', JSON.stringify(CS));
    }



    enuncitedShow(){
        return this.state.enunciated;
    }

    questionShow(){
        return this.state.question;
    }

    optionShow(x){
        return this.state.options[x];
    }



    getCounter(){
        return this.state.counter;
    }

    skip(){
        Actions.FinishQuizz();
    }

    nextQuestion(){

        var number = counterInt;
        var number1 = number.toString();

        if(number1.localeCompare("10") == 0){
            Actions.FinishQuizz();
            return false;
        }

        if(nexType==0){
            Actions.SOLQMC();
        }else if(nexType==1){
            Actions.SOLQO();
        }else{
            Actions.SOLQTF();
        }
        
    }
    contentSizeChange = ({nativeEvent:event}) => {
        this.setState({ textAreaHeight: event.contentSize.height });
    };
    render() {

        const {textAreaHeight } = this.state;

        return (
            <Wallpaper>

                <Text style={styles.textEnunciated}>Solution nº {this.getCounter()}</Text>
                <Text style={styles.textEnunciated}>Enunciated</Text>
                <View style={styles.textViewEnunciatedMain}>
                    
                    <ScrollView /*style={styles.textEnunciatedMain}*/>  
                        
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.enuncitedShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>
                <Text style={styles.textEnunciated}>Question</Text>
                <View style={styles.textViewQuestionMain} >
                    <ScrollView>
                        <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                            value={this.questionShow()}
                            onContentSizeChange={this.contentSizeChange}
                            multiline
                            editable = {false}
                        />
                    </ScrollView>
                </View>

                <ScrollView nestedScrollEnabled = {true}>
                
                    
                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 1</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                //keyboardType='numeric'
                                //onChangeText={option1Order => this.setState({ option1Order })}
                                value={this.getCorrectOrder(0)}
                                maxLength={1}  //setting limit of input
                                editable = {false}
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(0)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 2</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                //onChangeText={option2Order => this.setState({ option2Order })}
                                value={this.getCorrectOrder(1)}
                                maxLength={1}  //setting limit of input
                                editable = {false}
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(1)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 3</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                //onChangeText={option3Order => this.setState({ option3Order })}
                                value={this.getCorrectOrder(2)}
                                maxLength={1}  //setting limit of input
                                editable = {false}
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(2)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>


                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 4</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                //onChangeText={option4Order => this.setState({ option4Order })}
                                value={this.getCorrectOrder(3)}
                                maxLength={1}  //setting limit of input
                                editable = {false}
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(3)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>

                    
                    <View style={styles.textViewOptionMain} >

                        <Text style={styles.textOption}>Option 5</Text>

                        <View style={styles.radioButtons} >
                            <TextInput 
                                style={styles.numberInput}
                                keyboardType='numeric'
                                //onChangeText={option5Order => this.setState({ option5Order })}
                                value={this.getCorrectOrder(4)}
                                maxLength={1}  //setting limit of input
                                editable = {false}
                                
                            />
                        </View>

                        <View style={styles.textViewOption} >
                            <ScrollView nestedScrollEnabled = {true}>
                                <TextInput style={{ height: textAreaHeight } && styles.textAreaEnunciated}
                                    value={this.optionShow(4)}
                                    onContentSizeChange={this.contentSizeChange}
                                    multiline
                                    editable = {false}
                                />
                            </ScrollView>
                        </View>

                    </View>
                    <TouchableHighlight style ={styles.skipButton}>
                        <Button onPress={()=> {this.skip()}}            
                        title="SKIP"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight> 
                    <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.nextQuestion()}}            
                        title="NEXT"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                    </TouchableHighlight>
                    <Text> </Text>
                    <Text> </Text> 
                </ScrollView>
            </Wallpaper>
        );
    }
}


const styles = StyleSheet.create({

    textViewEnunciatedMain: {
        maxHeight: 160,
        borderWidth: 3,
        borderColor: 'black',
     },

     textViewQuestionMain: {
        maxHeight: 100,
        borderWidth: 3,
        borderColor: 'black',
     },

    textEnunciated: {
        marginLeft: 10,
        fontSize: 18,
        color: 'white',
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textAreaEnunciated: {
        fontSize: 15,
        color: 'black',
        backgroundColor: 'silver',
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textOption: {
        marginLeft: 10,
        fontSize: 16,
        color: Colors.orange500,
        height: 30,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    textViewOptionMain: {
        // height: 'auto',

     },

     radioButtons: {
        //marginTop:35,
        borderColor: 'black',
        borderWidth: 3,
        backgroundColor: 'silver',
        width:30,
        height: 40,
        marginTop:0,
     },

     numberInput: {
        marginTop: -3,
        width:100,
        color:'black',
     },

    textViewOption: {
        maxHeight: 160,
        borderColor: 'black',
        marginTop:-40,
        // height: 'auto',
         marginLeft: 35,
        // borderColor: '#c0c0c0',
         borderWidth: 3,
         padding: 0,
     },



     textAreaOption: {
        backgroundColor: 'silver',
        fontSize: 15,
        color: 'black',
        height: 100,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },
    skipButton: {
        
        height: 40,
        width:100,
        marginLeft :70,
        marginTop :20,
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :200,
        marginTop :-40,
    },
  })