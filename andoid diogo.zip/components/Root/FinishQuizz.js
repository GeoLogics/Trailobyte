//copiar codigo loginScreen e adaptar
//adicionar ao Root.js
//se tiver alguma duvida verificar zip "src Diogo para o final com as cenas do joao"
//e
//se tiver alguma duvida verificar zip "src diogo com QO validate old look"
//estao ambos no ambiente de trabalho


import React from "react";


//import UserForm from './UserForm';
import Wallpaper from './Wallpaper';


import { StyleSheet, Button, Text, Alert, View, TextInput, TouchableHighlight, ScrollView, TouchableOpacity} from 'react-native';
import { RadioButton, Colors } from 'react-native-paper';

import { Actions } from 'react-native-router-flux';

import SyncStorage from 'sync-storage';

var Thread = {
    sleep: function() {
        var start = Date.now();
        
        while (true) {
            var clock = (Date.now() - start);
            if (clock >= 1000) break;
        }
        
    }
};

export default class Quizz extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            answersList:[],
            result:'',
            counter:'',
        };
    
    }

    componentWillMount(){

        const counterJSON = SyncStorage.get('counter')
        var counter = JSON.parse(counterJSON);
        this.setState({ counter: counter.counter })

        var answersListFromDB=[];

        for(var i=0; i < 10;i++){
            var j = i+1;
            const answerJSON = SyncStorage.get('answer' + j);
            answer = JSON.parse(answerJSON);
            answersListFromDB[i]= answer.answer;
        }

        /*const answer1JSON = SyncStorage.get('answer1');
        answer1 = JSON.parse(answer1JSON);

        const answer2JSON = SyncStorage.get('answer2');
        answer2 = JSON.parse(answer2JSON);

        const answer3JSON = SyncStorage.get('answer3');
        answer3 = JSON.parse(answer3JSON);

        var answersListFromDB = [answer1.answer, answer2.answer, answer3.answer];
*/

        var result1 =0;
        for(var i =0; i < answersListFromDB.length ;i++){
           // Alert.alert(this.state.answersList[i].toString());
            if(answersListFromDB[i]==true){
                result1++;
            }
        }
        //Alert.alert(result1.toString());
        this.setState({ result: result1.toString() })

        return false;
    }

    delete(){
        SyncStorage.remove('counter');

        /*SyncStorage.remove('QMC');
        SyncStorage.remove('QO');
        SyncStorage.remove('QTF');

        SyncStorage.remove('answer1');
        SyncStorage.remove('answer2');
        SyncStorage.remove('answer3');*/
    }

    solutions(){
        CS = {counter : 1};
        SyncStorage.set('CS', JSON.stringify(CS));

        var CTJSON = SyncStorage.get('CT'+ 1);
        var CT = JSON.parse(CTJSON);
        var nexType = CT.type;

        //alterar para ir para solucoes
        if(nexType==0){
            Actions.SOLQMC();
        }else if(nexType==1){
            Actions.SOLQO();
        }else{
            Actions.SOLQTF();
        }
    }

    endQuizz = () => {

        this.delete();

        Actions.Quizz();

        
    }

    counterShow(){
        return this.state.counter;
    }
    resultShow(){
        return this.state.result;
    }

    render() {
        return (
            <Wallpaper>
                <View style={styles.radioButtons} >
                    <Text style={styles.textEnunciated}>Result: {this.resultShow()}/{this.counterShow()-1}</Text>
                </View>
                
                <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.endQuizz()}}            
                        title="Finish"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight> 

                <TouchableHighlight style ={styles.submitButton}>
                        <Button onPress={()=> {this.solutions()}}            
                        title="View Solutions"
                        accessibilityLabel="Learn more about this button"
                        color = "#708090"
                    /> 
                </TouchableHighlight> 
            </Wallpaper>
        );
    }
}

const styles = StyleSheet.create({

    textEnunciated: {
        marginTop :200,
        marginLeft :90,
        fontSize: 40,
        color: Colors.grey700,
        height: 50,
        justifyContent: "flex-start",
        textAlignVertical: 'top',
    },

    submitButton: {
        
        height: 40,
        width:100,
        marginLeft :130,
        marginTop :20,
    },
  })