import React from 'react';
import { Router, Scene } from 'react-native-router-flux';

import SplashScreen from './Root/SplashScreen';
import LoginScreen from './Root/LoginScreen';
import RegisterScreen from './Root/RegisterScreen';
import UserTrailScreen from './Root/UserTrailScreen';
import UserQuizzScreen from './Root/UserQuizzScreen';
import UserQuizzQuestionScreen from './Root/UserQuizzQuestionScreen';
import UserAreaScreen from './Root/UserAreaScreen';

import FinishQuizz from './Root/FinishQuizz';
import Quizz from './Root/Quizz';
import QuestionQMC from './Root/QuestionQMC';
import QuestionQO from './Root/QuestionQO';
import QuestionQTF from './Root/QuestionQTF';
import Load from './Root/LoadNewQuest';
import SolQMC from './Root/SolutionQMC';
import SolQO from './Root/SolutionQO';
import SolQTF from './Root/SolutionQTF';

export default class Main extends React.Component {
    render() {
        return (
            <Router>
                <Scene key="root">
                    <Scene key="splashScreen"
                        component={SplashScreen}
                        animation='fade'
                        hideNavBar={true}
                        initial={true}
                    />
                    <Scene key="loginScreen"
                        component={LoginScreen}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="registerScreen"
                        component={RegisterScreen}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="userTrailScreen"
                        component={UserTrailScreen}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="userQuizzScreen"
                        component={UserQuizzScreen}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="userQuizzQuestionScreen"
                        component={UserQuizzQuestionScreen}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="userAreaScreen"
                        component={UserAreaScreen}
                        animation='fade'
                        hideNavBar={true}
                    />

                    <Scene key="LoadNewQuestions"
                        component={Load}
                        animation='fade'
                        hideNavBar={true}
                        //initial={true}
                    />

                    <Scene key="Quizz"
                        component={Quizz}
                        animation='fade'
                        hideNavBar={true}
                        //initial={true}
                    />
                    <Scene key="QMC"
                        component={QuestionQMC}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="QO"
                        component={QuestionQO}
                        animation='fade'
                        hideNavBar={true}
                    />
                    <Scene key="QTF"
                        component={QuestionQTF}
                        animation='fade'
                        hideNavBar={true}
                    />

                    <Scene key="FinishQuizz"
                        component={FinishQuizz}
                        animation='fade'
                        hideNavBar={true}
                    />

                    <Scene key="SOLQMC"
                        component={SolQMC}
                        animation='fade'
                        hideNavBar={true}
                    />

                    <Scene key="SOLQO"
                        component={SolQO}
                        animation='fade'
                        hideNavBar={true}
                    />                    
                    <Scene key="SOLQTF"
                        component={SolQTF}
                        animation='fade'
                        hideNavBar={true}
                    />

                </Scene>
            </Router>
        );
	}
}