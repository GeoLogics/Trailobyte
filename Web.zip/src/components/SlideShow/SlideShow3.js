
import img1 from './penedo lexim 1.jpeg';
import img2 from './penedo lexim 2.jpg';
import img3 from './penedo lexim 3.jpg';
import img4 from './penedo lexim 4.jpg';
import img5 from './penedo lexim 5.jpg';
import img6 from './grutas de mira de aire.jpg';

import React from 'react';
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";
import "./Slides.css";

export default class Slide extends React.Component {
    render() {
        const images = [
            {
                original: img1,
                thumbnail: img1,
            },
            {
                original: img2,
                thumbnail: img2,
            },
            {
                original: img3,
                thumbnail: img3,
            },
            {
                original: img4,
                thumbnail: img4,
            },
            {
                original: img5,
                thumbnail: img5,
            },
            {
                original: img6,
                thumbnail: img6,
            },
            
        ]
        return (
            <ImageGallery items={images} autoPlay={true} showFullscreenButton={false} showPlayButton={false} showThumbnails={false} slideInterval={6000} additionalClass={"slides"}/>
        );
    }
}