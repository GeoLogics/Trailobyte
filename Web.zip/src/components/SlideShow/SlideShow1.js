import img1 from './Algar-de-Benagil.jpg';
import img2 from './Algar-de-Benagil2.jpg';
import img3 from './Grutas-de-Mira-de-Aire.jpg';
import img4 from './Grutas-de-Santo-Antonio.png';
import img5 from './grutas de mira de aire 1.jpg';

import React from 'react';
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";
import "./Slides.css";

export default class Slide extends React.Component {
    render() {
        const images = [
            {
                original: img1,
                thumbnail: img1,
            },
            {
                original: img2,
                thumbnail: img2,
            },
            {
                original: img3,
                thumbnail: img3,
            },
            {
                original: img4,
                thumbnail: img4,
            },
            {
                original: img5,
                thumbnail: img5,
            },
        
            
        ]
        return (
            <ImageGallery items={images} autoPlay={true} showFullscreenButton={false} showPlayButton={false} showThumbnails={false} slideInterval={6000} additionalClass={"slides2"}/>
        );
    }
}