import React ,{useState} from 'react';
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tab from '@material-ui/core/Tab';
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import NavBar from '../utils/navbar';
import AdminArea from "./AdminArea";
import Trails from "./Trails";
import VerifyQuestions from "./VerifyQuestions";
import { lightGreen } from '@material-ui/core/colors';


const useStyles = makeStyles((theme) => ({
  root: {
    backgroundImage: "url('/imagens/montanha.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    width: "100%",
    minWidth: "70em",
    minHeight: "100%",
    position: "absolute",
    backgroundAttachment: "fixed",
  },
  tabs:{
    backgroundColor: "#8c8c8c",
    indicatorColor: theme.palette.secondary.main
  }
}));

const theme = createMuiTheme({
  palette: {
    secondary: {
      main: lightGreen[500],
    },
  },
});

export default function LabTabs() {
  const classes = useStyles();
  const [value, setValue] = useState('1');


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  /*
        <TabPanel value="2"><DeleteTrails/></TabPanel>
        <TabPanel value="4"><VerifyTrails/></TabPanel>
        <TabPanel value="5"><VerifyComms/></TabPanel>*/
  return (
    <div className={classes.root}>
        <NavBar></NavBar>
      <TabContext value={value}>
        <AppBar position="static">
          <ThemeProvider theme={theme}>
          <TabList onChange={handleChange} aria-label="simple tabs example" className={classes.tabs}>
            <Tab label="Admin area" value="1" />
            <Tab label="Trails" value="2" />
            <Tab label="Verify questions" value="5" />
          </TabList>
          </ThemeProvider>
        </AppBar>
        <TabPanel value="1"><AdminArea/></TabPanel>
        <TabPanel value="2"><Trails/></TabPanel>
        <TabPanel value="5"><VerifyQuestions/></TabPanel>
      </TabContext>
    </div>
  );
}