import React, {useState,useEffect} from 'react';
import TableTrails from './DeleteTrail';
import TableTrailsUn from './TrailsUnverified';
import { makeStyles } from '@material-ui/core/styles';
import { TextField } from '@material-ui/core';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
    root: {
      width: '100%',
    },
    container: {
      maxHeight: 440,
    },
    textField: {
        marginTop:"20px",
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: '99%',
        backgroundColor:"#b6b6af",
      },
      button:{
        float:"right",
        marginRight:"105px",
        fontSize:"80%",
        marginTop:"4px"
    }
  }));

  function createData(name, creator, start, end, avgRating, nRatings, dist) {
    return { name, creator, start, end, avgRating, nRatings, dist };
  }


export default function Trail(){
    const classes = useStyles();
    const [name,setName] = useState('');
    const [deletename,setDelete] = useState('');
    const [rows,setRows] = useState([]);
    const [rowsun,setRowsun] =useState([]);


    function getTrails(){
            const username = localStorage.getItem("username");
            const key = localStorage.getItem("key");
      
            var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append("accept","application/json");
      
            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };
      
            fetch('https://trailobyte-275015.ew.r.appspot.com/rest/query/listTrails', requestOptions)
            .then(async (response) =>{ 
                var temp = await response.json();
                var array= [];
                for(let i=0; i < temp.resultList.length; i++){
                    var newArray = array.concat(createData(temp.resultList[i].name,
                        temp.resultList[i].creator,
                        temp.resultList[i].start,
                        temp.resultList[i].end,
                        temp.resultList[i].avgRating,
                        temp.resultList[i].nRatings,
                        temp.resultList[i].dist));
                    array = newArray;
                }
                setRows(array);
            }).catch(error => alert("Server not available"));
        }

      function getTrailsUnverified(){
            const username = localStorage.getItem("username");
            const key = localStorage.getItem("key");
    
            var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append("accept","application/json");
    
            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };
    
            fetch('https://trailobyte-275015.ew.r.appspot.com/rest/query/listTrailsUnverified', requestOptions)
            .then(async (response) =>{ 
                var temp = await response.json();
                console.log(temp);
                var array= [];
                for(let i=0; i < temp.resultList.length; i++){
                    var newArray = array.concat(createData(temp.resultList[i].name,
                        temp.resultList[i].creator,
                        temp.resultList[i].start,
                        temp.resultList[i].end,
                        temp.resultList[i].avgRating,
                        temp.resultList[i].nRatings,
                        temp.resultList[i].dist));
                    array = newArray;
                }
                setRowsun(array);
            }).catch(error => alert("Server not available"));
        }
    

    useEffect(() => {
        getTrailsUnverified();
        getTrails();
    },[])

    const handleChange = (event) => {
        setName(event.target.value);
  };

  const handleChangeDelete = (event) => {
    setDelete(event.target.value);
};

function submit() {
    if(!deletename){
        return null;
    }
    const username = localStorage.getItem("username");
    const key = localStorage.getItem("key");
    var myHeaders = new Headers();
        myHeaders.append("username", username);
        myHeaders.append("Authorization", "Bearer " + key);

    var requestOptions = {
        method: 'DELETE',
        headers: myHeaders,
    };


    fetch('https://trailobyte-275015.ew.r.appspot.com/trail/deleteTrail/'+ deletename ,requestOptions)
    .then(async (response) =>{ 
        var temp = await response;
        if(temp.ok){
            alert("Done!");
            setDelete('');

        }
        else{
            alert("That user does not exist, please check the list!");
        }
    }).catch(error => alert("Server not available"));
}

function submitVerify(){
    if(!name){
        return;
    }
    const username = localStorage.getItem("username");
    const key = localStorage.getItem("key");
    var myHeaders = new Headers();
        myHeaders.append("username", username);
        myHeaders.append("Authorization", "Bearer " + key);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
};


    fetch('https://trailobyte-275015.ew.r.appspot.com/trail/OPT2OP/' + name,requestOptions)
    .then(async (response) =>{ 
        var temp = await response;
        if(temp.ok){
            alert("Done!");
            setName('');
        }
        else{
            alert("That user does not exist, please check the list!");
        }
    }).catch(error => alert("Server not available"));
}

    return(
        <div>
            <h1>Verify Trails</h1>
            <TableTrailsUn rows={rowsun}/>
            <TextField
            className={classes.textField}
          color="primary"
          placeholder="Trail name to verify"
          variant="outlined"
          onChange={handleChange} 
          value={name}/>
          <Button color="primary" className={classes.button} onClick={()=>submitVerify} variant="contained">Verify</Button>
            <h1>Delete Trails</h1>
            <TableTrails rows={rows}/>
            <TextField
            className={classes.textField}
          error
          placeholder="Trail name to delete"
          variant="outlined"
          onChange={handleChangeDelete} 
          value={deletename}/>
        <Button color="secondary" className={classes.button} onClick={()=>submit}  variant="contained">Delete</Button>

        </div>
        );

    }