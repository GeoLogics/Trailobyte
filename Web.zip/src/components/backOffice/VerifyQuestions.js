import React, {useState,useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import TrailView from '../trailView/trailResume';
import img from '../trailView/Grutas-de-Mira-de-Aire.jpg';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Pagination from '@material-ui/lab/Pagination';
import {Button,TextField} from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    alignItems: "center",
    justifyContent:"center"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    height: "80%",
  },
  grid: {
      height:"75vh",
      marginTop:"20px",
  },
  divheader:{
    textAlign: "center",
    fontSize: "150%",
    color: "white",
    textShadow: "1px 1px black",
},
pagi:{
  marginLeft:"40%"  
},
textField: {
  marginTop:"20px",
  marginLeft: theme.spacing(1),
  marginRight: theme.spacing(1),
  width: '99%',
  backgroundColor:"#b6b6af",
},
button:{
  float:"right",
  marginRight:"105px",
  fontSize:"80%",
  marginTop:"4px"
}
}));

/*var trails = {
  name:"SintraCascaisasdsasda",
  description:"percurso de cascais a sintraassadsdasadsdaasdsdadasasdasdasdsda saddddddddssssssssssdddddddddddd ddddsssssssssssssssssssssssssssssssssssssss sssssssssssssssssssssssssssssssssssssss",
  trailImg:img,
  creator: "xd1",
  start:"Boca do Inferno",
  end:"Sintra",
  markers:[
  {
      name: "Boca do Inferno",
      coords:{"lat":38.691369,"lng":-9.430619},
      content:"Acidente geológico integrado num campo de lapiás, que corresponde a uma enorme caverna cujo teto abateu, devido à força erosiva das ondas e à dissolução dos calcários pela água das chuvas. A visitar ainda alguns elementos singulares, tais como a chaminé vulcânica na praia do Guincho, o sistema dunar Guincho-Oitavos e a duna consolidada de Oitavos. Prosseguir pela N247;",
      imgURL:img,
      iconImg:
      {
          url:"/images/start.png",
          size:{"width":512,"height":512},
          scaledSize:{"width":56,"height":56},
          origin:{"x":0,"y":0},
          anchor:{"x":28,"y":56}
      },
      stopover: true
  },
  {
      coords:{"lat":38.708095,"lng":-9.484173},
      iconImg:null,
      content: null,
      stopover:false
  },
  {
      name:"Abano",
      coords:{"lat":38.722477,"lng":-9.477907},
      content:"Linha de costa, pontuada pelo Forte do Guincho, apresenta grande interesse em termos geológicos.",
      imgURL:img,
      iconImg:null,
      stopover:true	
  },
  {	
      name:"Cabo da Roca",
      coords:{"lat":38.7804,"lng":-9.4989},
      content:"O “Promontório Magno” dos Romanos, é um miradouro natural por excelência sobre o mar, que em dias límpidos permite a visibilidade até às Berlengas.",
      imgURL:img,
      iconImg:null,
      stopover:true
  },
  {
      name:"Ribeira de Colares",
      coords:{"lat":38.803533,"lng":-9.449552},
      content:"É dominada pela depressão onde a sinuosa ribeira marca o seu percurso em direção ao mar.",
      imgURL:img,
      iconImg:null,
      stopover:true				
  },
  {
      name:"Serra de Sintra",
      coords:{"lat":38.80181,"lng":-9.395254},
      content:"Apresenta uma forte identidade que lhe advém de um peso histórico e cultural indiscutível.",
      imgURL:img,
      iconImg:null,
      stopover:true
  },
  {
      name:"Sintra",
      coords:{"lat":38.8029,"lng":-9.3817},
      content:"Situada na encosta norte da serra de Sintra, o enquadramento harmonioso da vila de Sintra, parques e quintas com os seus palácios e edifícios senhoriais, criaram “uma combinação única de parques e jardins que influenciou o desenvolvimento das paisagens na Europa” (UNESCO, 1996). Tanto em Sintra como na sua envolvente existem numerosos locais a visitar como o Parque da Pena, Quinta da Regaleira, Convento dos Capuchos, Pedras Irmãs, Anta de Adrenunes e Peninha.",
      imgURL:img,
      iconImg:
      {
          url:"/images/finish.png",
          size:{"width":512,"height":512},
          scaledSize:{"width":56,"height":56},
          origin:{"x":0,"y":0},
          anchor:{"x":28,"y":56}
      },
      stopover:true
  }
],
avgRating: 6.0,
nRatings: 0,
dist:25.0,
verified: true	
};

var question = {
  questionkey:"12",
  author:"asd",
  trailname:"asdsa",
  marker:"asdsa",
  question:"asdsa",
  optiona:"asdsa",
  optionb:"asdsa",
  optionc:"asdsa",
  optiond:"asdsa",
  answer:"asdsa",
}*/

export default function FullWidthGrid() {
  const classes = useStyles();
  const [trail,setTrail] = useState(null);
  const [questions,setQuestions] = useState([]);
  const [page, setPage] = useState(1);
  const [questionKey,setQuestionkey] = useState('');
  
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    getTrail(questions[newPage-1].trailname);
  };

  const handleChangeQuestionKey = (event) => {
    setQuestionkey(event.target.value);
  }


  useEffect(()=>{
      getQuestions();
  },[]);

  const getQuestions = () => {
    const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append("content-type","application/json");

        var requestOptions = {
            method: 'POST',
            header: myHeaders
          };

  fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT7OP/',requestOptions)
   .then(async (response) => {
       var temp = await response.json();
       setQuestions(temp);
       getTrail(temp[0].name);
       })
   .catch(error => alert("Server not available"));
}

  const verify = (name) => {
    const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append("content-type","application/json");
        var requestOptions = {
            method: 'POST',
            header: myHeaders
          };

  fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT6OP/'+ name,requestOptions)
   .then(async (response) => {
       var temp = await response;
       if(temp.ok){
         alert("Done!");
         getQuestions;
       }

       })
   .catch(error => alert("Server not available"));
}

  const getTrail = (name) => {
    var requestOptions = {
        method: 'GET',
        header: {
          'Accept': 'application/json',
      },
        body: JSON.stringify({questionKey:questionKey}),
    };

  fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT3OP/'+ name,requestOptions)
     .then(async (response) => {
         var temp = await response.json();
         setTrail(temp);
         })
     .catch(error => alert("Server not available"));
 }


  

  return (
    <div className={classes.root}>
        <div className={classes.divheader}>
            <h3>VERIFY QUESTION</h3>
        </div>
        <Grid container spacing={3} className={classes.grid}>
            <Grid item xs={3}>
  <Paper className={classes.paper}>{trail ? <TrailView trail={trail}/> : null}</Paper>
            </Grid>
            <Grid item xs={9}>
              <Grid item xs={12}>
                {questions ? 
                <Paper className={classes.root}>
        {questions.map((question,index) => {
          if(page-1 == index){
            return(<div key={index}>
                <TableContainer component={Paper}>
                  <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                      <TableRow>
                        <TableCell>Question Key</TableCell>
                          <TableCell align="right">Author</TableCell>
                          <TableCell align="right">Trailname</TableCell>
            <TableCell align="right">Marker</TableCell>
            <TableCell align="right">Question</TableCell>
            <TableCell align="right">Option A</TableCell>
            <TableCell align="right">Option B</TableCell>
            <TableCell align="right">Option C</TableCell>
            <TableCell align="right">Option D</TableCell>
            <TableCell align="right">Answer</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
            <TableRow key={index}>
            <TableCell component="th" scope="row">
                {question.questionkey}
              </TableCell>
              <TableCell align="right">
                {question.author}
              </TableCell>
              <TableCell align="right">{question.trailname}</TableCell>
              <TableCell align="right">{question.marker}</TableCell>
              <TableCell align="right">{question.question}</TableCell>
              <TableCell align="right">{question.optiona}</TableCell>
              <TableCell align="right">{question.optionb}</TableCell>
              <TableCell align="right">{question.optionc}</TableCell>
              <TableCell align="right">{question.optiond}</TableCell>
              <TableCell align="right">{question.answer}</TableCell>
            </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
            </div>);
          }
          else
              return(null);
        })
        }
        <Pagination count={questions.length} page={page} onChange={handleChangePage} className={classes.pagi}/>
    </Paper> : null}
            </Grid>
            <Grid>
            <TextField
            className={classes.textField}
          color="primary"
          placeholder="Trail name to verify"
          variant="outlined"
          onChange={handleChangeQuestionKey} 
          value={questionKey}/>
          <Button color="primary" className={classes.button} onClick={verify} variant="contained">Verify</Button>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
}