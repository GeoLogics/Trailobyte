import React, {useState} from 'react';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';


const useStyles = makeStyles((theme) => ({
    root: {},
      div:{
        marginLeft: "50px",
        paddingTop:"20px",
    },
    paper: {
        marginTop:"100px",
        width: "100%",
        height: "110px",
        backgroundColor: "#eaeae1",
    },
    divheader:{
        marginTop:"50px",
        textAlign: "center",
        fontSize: "150%",
        color: "#eaeae1",
        textShadow: "1px 1px black",
    },
    divheader2:{
        marginTop:"100px",
        textAlign: "center",
        fontSize: "150%",
        color: "#eaeae1",
        textShadow: "1px 1px black",
    },
    divinput:{
        float:"right",
        width:"300px",
        marginTop:"10px"
    },
    divinput2:{
        float:"right",
        marginTop:"10px",
        width:"400px"
    },
    ptext:{
        marginLeft:"15%",
        marginTop:"13px",
    },
    container:{
        width:"80%"
    },
    select: {
        minWidth: 90,
      },
      input:{
          marginTop:"1px",
      },
      button:{
          float:"right",
          marginRight:"105px",
          fontSize:"80%",
          marginTop:"4px"
      }
}));
  

export default function SimpleContainer() {

    const [input,setInput] = useState('');
    const [role,setRole] = useState('');
    const [accounttochange, setAccount] = useState('');

    const classes = useStyles();


  const handleChange = (event) => {
    setRole(event.target.value);
  };

    function submit() {
        if(!input){
            return null;
        }
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);

    var requestOptions = {
        method: 'DELETE',
        headers: myHeaders,
    };


        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/remove/OPX2OP/' + input,requestOptions)
        .then(async (response) =>{ 
            var temp = await response;
            if(temp.ok){
                alert("Done!");
                //remover da lista
            }
            else{
                alert("That user does not exist, please check the list!");
            }
        }).catch(error => alert("Server not available"));
    }

    function submitRole(){
        if(!accounttochange || !role){
            return null;
        }
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append('content-type','application/json');

    var requestOptions = {
        method: 'PUT',
        headers: myHeaders,
        body:JSON.stringify({
            username: accounttochange,
            role: role,
        }),
    };


        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/roles/OPX1OP',requestOptions)
        .then(async (response) =>{ 
            var temp = await response;
            if(temp.ok){
                alert("Done!");
                //Trocar na lista
            }
            else{
                alert("That user does not exist, please check the list!");
            }
        }).catch(error => alert("Server not available"));
    }

  return (
      <Container className={classes.container}>
          <div className={classes.divheader}>
            <h3>DELETE ACCOUNT</h3>
          </div>
      <Paper elevation={3} className={classes.paper}>
      <Grid container spacing={3}>
      <Grid item xs={6}>
            <p className={classes.ptext}>The trails will remain in the database!</p>
            <p className={classes.ptext}>This can't be undone!</p>
        </Grid>
        <Grid item xs={6}>
        <div className={classes.divinput}>
                    <Input placeholder="Account name to delete" className={classes.input2} inputProps={{ 'aria-label': 'description' }} value={input} onChange={e => setInput(e.target.value)} color="secondary"/><br/>
                    <Button color="secondary" className={classes.button} onClick={()=>submit()}>Delete</Button>
                </div>
                </Grid>
            </Grid>
        </Paper>
        <div className={classes.divheader2}>
            <h3>CHANGE ROLE</h3>
        </div>
        <Paper elevation={3} className={classes.paper}>
        <Grid container spacing={3}>
            <Grid item xs={6}>
                <p className={classes.ptext}>Be careful who you give permissions to!</p>
                <p className={classes.ptext}>It may be too late!</p>
            </Grid>
            <Grid item xs={6}>
                <div className={classes.divinput2}>
                        <Select
                        id="demo-simple-select"
                        value={role}
                        onChange={handleChange}
                        className={classes.select}
                        displayEmpty
                        >
                        <MenuItem value="" disabled>
                        ROLE
                        </MenuItem>
                        <MenuItem value="E1">E1</MenuItem>
                        <MenuItem value="E2">E2</MenuItem>
                        <MenuItem value="BO">BO</MenuItem>
                        <MenuItem value="BOT">BOT</MenuItem>
                        <MenuItem value="ADMIN">ADMIN</MenuItem>
                    </Select>
                    <Input placeholder="Account name to change" inputProps={{ 'aria-label': 'description' }} onChange={e => setAccount(e.target.value)} color="primary" className={classes.input}/>
                    <Button color="primary" className={classes.button} onClick={()=>submitRole()}>Change role</Button>
                </div>
                </Grid>
            </Grid>
        </Paper>
      </Container>
  );
}