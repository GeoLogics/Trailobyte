/*global google*/
import React, {useState, useEffect} from 'react';
import { GoogleMap, withGoogleMap,withScriptjs,Marker,DirectionsRenderer} from "react-google-maps";
import _ from 'lodash';
import { makeStyles } from '@material-ui/core/styles';
import Rating from '@material-ui/lab/Rating';
import Avatar from '@material-ui/core/Avatar';
import Pagination from '@material-ui/lab/Pagination';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';
import Waypoints from '../utils/Waypoints';
import Comments from '../utils/Comments';


const Map = withScriptjs(
    withGoogleMap(props => (
        <GoogleMap
        defaultZoom={10} 
        defaultCenter={props.center}
        >
            {props.marks.map((mark, index) => (
                <Marker
                key={index}
                position={mark.coords}
                onClick={e => props.onMapClick3(e,index)}
            />
            ))}
        
        {props.directions && <DirectionsRenderer directions={props.directions} defaultOptions={{suppressMarkers: true}} />}
        </GoogleMap>
    ))
);

const useStyles = makeStyles((theme) => ({
    large: {
        width: theme.spacing(8),
        height: theme.spacing(8),
        float:"left",
      },
    h: {
        width: "300px",
        marginBottom:"5px"
    },
    p:{
        marginTop:"5px"
    },
    paper1:{
        width: "90%",
        backgroundColor:"#eaeae1",
    },
    root:{
        backgroundColor:"#eaeae1",
    },

}));

function gotoback() {
    history.go(-1);
}

export default function MapTest6(props){
    const [directions,setDirections] = useState(null);
    const [marks,setMarks] = useState([]);
    const [name,setName] = useState(null);
    const [description,setDescription] = useState(null);
    const [start,setStart] = useState(null);
    const [end,setEnd] = useState(null);
    const [trailImg,setTrailImg] = useState(null);
    const [dist,setDist] = useState(null);
    const [avgRating,setAvgRating] = useState(null);
    const [nRatings,setnRatings] = useState(null);
    const [verified,setVerified] = useState(null);
    const [area,setArea] = useState(null);
    const [selected,setSelected] = useState(null);
    const [center,setCenter] = useState({lat:38.7071, lng: -9.13549});
    const [loading,setLoading] = useState(true);
    const [creator,setCreator] = useState(null);
    const [comments,setComments] = useState(null);

    const [page, setPage] = React.useState(1);
    const handleChange = (event, value) => {
        setPage(value);
    };

    const classes = useStyles();
    

    const getDirection = () => {
        const directionsService = new google.maps.DirectionsService();

        const markers = marks;

        setDirections(null);

        const origin = markers[0].coords;
        const destination = markers[Object.keys(markers).length-1].coords;
        const waypts = [];

        for( let i=1; i<Object.keys(markers).length-1;i++){
            let location = {
                location: markers[i].coords,
                stopover: markers[i].stopover,
            };
            waypts.push(location);
        }

        directionsService.route({
            origin: origin,
            destination: destination,
            travelMode: google.maps.TravelMode.DRIVING,
            waypoints: waypts,
          }, (result, status) => {
            if (status === google.maps.DirectionsStatus.OK) {
                setDirections(result);
              let distance = _.flatMap(result.routes, route => _.flatMap(route.legs, leg => leg.distance.value));  
              let sum = _.sum(distance);
              sum = sum/1000;
              setDist(sum);
            } else {
              console.error(`error fetching directions ${result}`);
            }
          });
    }

    const handleClickMarker = (event, index) => {
        setPage(index+1);
    }

    useEffect(() => {
        const { mapid } = props.match.params;
        load(mapid);
        getReviews(mapid);
    },[]);


    function getReviews(name){
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");

        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append('accept', 'application/json');
            myHeaders.append('content-type','application/json');

            var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    param:name,
                    pageSize: 10,
                }),
            };

            fetch('https://trailobyte-275015.ew.r.appspot.com/rest/query/trailReviews',requestOptions)
            .then(async (response) =>{ 
                var temp = await response.json();
                setComments(temp.resultList);
            }).catch(error => alert("Server not available"));
        };


    const submit = () => {
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
        
        var comment = {
            author:username,
            trailName: props.name,
            comment:message,
            rating:ratingFinal,
        };

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify(comment),
        };

         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT4OP',requestOptions)
        .then(async (response) =>{ 
                var temp = await response;
                if(temp.ok){
                    setComments(comment);
                }
            })
            .catch(error => alert("Server not available"));
        };

    const load = (name) => {
        var requestOptions = {
            method: 'GET',
            header: {'Accept': 'application/json'}
        };

    fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT3OP/'+ name,requestOptions)
       .then(async (response) => {
           var temp = await response.json();
           setName(temp.name);
           setDescription(temp.description);
           setStart(temp.start);
           setEnd(temp.end);
           setTrailImg(temp.trailImg);
           setDist(temp.dist);
           setAvgRating(temp.avgRating);
           setnRatings(temp.nRatings);
           setVerified(temp.verified);
           setArea(temp.area);
           setMarks(temp.markers);
           setCreator(temp.creator);
           setLoading(false);
           })
       .catch(error => alert("Server not available"));
   }
    

        return(
            <div style={{width:'100vw', height:'100vh'}} className={classes.root}>
                <button onClick={gotoback} id="backbutton">Back</button>
                <Map
                googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2HdYk7gSqjAnTchqAL4EilOOBWLjPExA"
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ height: `50%` }} />}
                mapElement={<div style={{ height: `100%` }} />}
                marks={marks}
                directions={directions}
                center={center}
                onMapClick3={handleClickMarker}
                selected={selected}
                >
                </Map>
                <div>
                    <Grid container>
                        <Grid item xs={4}>
                            <Grid item xs={12}>
                                <Paper className={classes.paper} elevation={0} className={classes.paper1}>
                                    <Grid container>
                                        <Grid item xs={2}>
                                            <Avatar alt={name} src={trailImg} className={classes.large}/>
                                        </Grid>
                                        <Grid item xs={9}>
                                            <Grid container>
                                                <Grid item xs={12}>
                                                    <h2 className={classes.h}>{name}</h2>
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <p className={classes.p}>by: {creator}</p>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Paper>
                                <Rating name="read-only" value={avgRating} readOnly />
                            </Grid>
                            <Grid item xs={12}>
                                <Paper className={classes.paper1} elevation={0}>
                                    <h3>Description</h3>
                                    <p>{description}</p>
                                </Paper>
                            </Grid>
                            <Grid item xs={6}>
                                <h3>Comments</h3>
                                {comments ? <Comments name={name} comments={comments}/> : <CircularProgress disableShrink />}
                            </Grid>
                        </Grid>
                        <Grid item xs={8}>
                            {loading ? <CircularProgress disableShrink /> : <Waypoints mark={marks[page-1]}/>}
                            <Pagination count={marks.length} page={page} onChange={handleChange} />
                        </Grid>
                    </Grid>
                </div>
            </div>
        );
    }
