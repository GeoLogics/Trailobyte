/*global google*/
import React, { useState, useEffect } from "react";
import { withScriptjs, withGoogleMap, GoogleMap, Marker, DirectionsRenderer} from "react-google-maps";
import './PostTrail.css';
import history from '../../history';
import _ from 'lodash';
import ImageUploader from 'react-images-upload';
import Pagination from '@material-ui/lab/Pagination';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';
import { Checkbox, FormControlLabel, IconButton, Button } from "@material-ui/core";
import DeleteIcon from '@material-ui/icons/Delete';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';


const useStyles = makeStyles((theme) => ({
    root:{
        backgroundColor:"#eaeae1",
    },
    paper:{
        backgroundColor:"#eaeae1",
    },
    
    textarea:{
        maxWidth:"90%",
        maxHeight:"80px",
        minWidth:"90%",
        minHeight:"80px"
    },
    textarea2:{
        maxWidth:"95%",
        maxHeight:"80px",
        minWidth:"95%",
        minHeight:"80px",
        marginTop:"10px"
    },
    h: {
        width: "300px",
    },
    paper1:{
        width: "90%"
    },
    pagi:{
        marginLeft:"45%",
    },
    deletebutton:{
        marginTop:"1%",
    },
    nomargin:{marginTop:"10px",
                marginBottom:"10px"
            }

}));

const Map = withScriptjs(
    withGoogleMap(props => (
        <GoogleMap
        defaultZoom={10} 
        defaultCenter={{lat:38.7071, lng: -9.13549}}
        onClick={e => props.onMapClick(e)}

        >
            {props.marks.map((mark, index) => (
                <Marker
                key={index}
                position={mark.coords}
            />
            ))}
        {props.directions && <DirectionsRenderer directions={props.directions} defaultOptions={{suppressMarkers: true}}/>}

        </GoogleMap>
    ))
);

const distritos = ["Aveiro",
    "Beja",
    "Braga",
    "Braganca",
    "Castelo Branco",
    "Coimbra",
    "Evora",
    "Faro",
    "Guarda",
    "Leiria",
    "Lisboa",
    "Portalegre",
    "Porto",
    "Santarem",
    "Setubal",
    "Viana do Castelo",
    "Vila Real",
    "Viseu",
    "Angra do Heroismo",
   "Funchal",
    "Horta",
    "Lamego",
    "Ponta Delgada"
]


export default function MapTest5(){
    const classes = useStyles();

    const [name,setName] = useState('');
    const [description,setDescription] = useState('');
    const [marks,setMarks] = useState([]);
    const [directions,setDirections] = useState(null);
    const [dist,setDist] = useState(0);
    const [picturetrail,setPictureTrail] = useState(null);
    const [area, setArea] = useState("Lisboa");
    const [page, setPage] = React.useState(1);
    const [submitted,setSubmitted] = useState("false");
    
    
    const handleChange = (event, value) => {
        setPage(value);
    };


    const onDrop2 = (event) => {
        setPictureTrail(event.target.files[0]);
    }

    function submit(event){
        if(!name){
            alert('Please insert a name');
            return null;
        }

        if(marks.length<2){
            alert('You need to select more waypoints');
            return null;
        }
        
        return 1;
    };

    function changeName(event){
        setName(event.target.value);
    };

    function changeDescription(event){
        setDescription(event.target.value);
    };

    const handleChangeSelect = (event) => {
        setArea(event.target.value);
      };


    const setMark = (e) => {
        var aux = {
            name: '',
            coords: e.latLng,
            content:'',
            imgURL: null,
            iconImg:null,
            stopover:true,
        }
        setMarks(marks => [...marks,aux]);
    };

    const deleteMarkS = () => {
        setMarks([]);
        setPage(1);
        setDirections(null);
    };

    const deleteMarker = (index) => e => {
        var array = marks // make a separate copy of the array
        array.splice(index, 1);
        setMarks(array);
        setPage(1);
        setDirections(null);
    }

    function getDirection(){
        if(marks.length<2){
            return;
        }
        const directionsService = new google.maps.DirectionsService();
        const markers = marks;
        setDirections(null);

        const origin = markers[0].coords;
        const destination = markers[Object.keys(markers).length-1].coords;
        const waypts = [];

        for( let i=1; i<Object.keys(markers).length-1;i++){
            let location = {
                location: markers[i].coords,
            };
            waypts.push(location);
        }

        directionsService.route({
            origin: origin,
            destination: destination,
            travelMode: google.maps.TravelMode.DRIVING,
            waypoints: waypts,
          }, (result, status) => {
            if (status === google.maps.DirectionsStatus.OK) {
              setDirections(result);
              let distance = _.flatMap(result.routes, route => _.flatMap(route.legs, leg => leg.distance.value));  
              let sum = _.sum(distance);
              sum = sum/1000;
              setDist(sum);
            } else {
              console.error(`error fetching directions ${result}`);
            }
          });
    }



    const handleChangeName = (index) => e => {
        var array = [...marks];  
        array[index].name = e.target.value;
        setMarks(array);
    }

    const handleChangeDesc = (index) => e => {
        var array = [...marks];  
        array[index].content = e.target.value;
        setMarks(array);
    }

    const handleChangeStopat = (index) => e => {
        var array = [...marks];  
        array[index].stopover = e.target.checked;
        setMarks(array);
      };


    function gotoApp(){
        history.push("/home");
    }

    function gotoback(){
        history.go(-1);
    }



    function postTrail(){
        var error = submit();
        getDirection();
        if(error == null)
            return;
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
  
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);

        var formdata = new FormData();
            formdata.append("json", JSON.stringify({
                name: name,
                description: description,
                trailImg: name+".jpg",
                creator: username,
                country:"Portugal",
                area: area,
                markers: marks,
                start: marks[0].name,
                end: marks[marks.length-1].name,
                avgRating: 0.0,
                nRatings: 0,
                dist: dist,
                verified: 'false'
            }));
            formdata.append('image', picturetrail, name+".jpg");


        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT1OP', requestOptions)
        .then(async (response) =>{ 
            var temp = await response;
            if(temp.ok){
                alert("Done!");
                setSubmitted("true");
                gotoApp();
            }
        }).catch(error => alert("Server not available"));
    };


    /*<ImageUploader
                                                withIcon={false}
                                                buttonText='Choose images'
                                                onChange={onDrop2}
                                                imgExtension={['.jpg','.png']}
                                                maxFileSize={5242880}
                                                singleImage={true}
                                                withPreview={true}
                                                label="Max file size:5mb, accepted: .jpg, .png"
                                                fileContainerStyle={{"backgroundColor":"#eaeae1", "boxShadow":"none","marginLeft":"0px","width":"200px"}}
                                                />*/

        return(
            <div style={{width:'100vw', height:'100vh'}} className={classes.root} >
                <button onClick={gotoback} id="backbutton">Back</button>
                <Map
                googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2HdYk7gSqjAnTchqAL4EilOOBWLjPExA"
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ height: `50%` }} />}
                mapElement={<div style={{ height: `100%` }} />}
                marks={marks}
                directions={directions}
                onMapClick={setMark}
                >
                </Map>
                <div>
                    <Grid container>
                        <Grid item xs={5}>
                            <Grid container>
                                <Grid item xs={6}>
                                    <Paper className={classes.paper} elevation={0}>
                                        <h3>Name</h3>
                                        <input type="text" placeholder="Trail name" id="trailname" value = {name} onChange={changeName} className="map"></input>
                                    </Paper>
                                    <Button variant="contained" onClick={()=>postTrail()} disable={submitted}>Submit</Button>
                                    <Button variant="contained" onClick={getDirection}>Preview</Button>
                                </Grid>
                                <Grid item xs={4}>
                                <InputLabel htmlFor="native-simple">Zone:</InputLabel>
                                <Select
                                    native
                                    value={area}
                                    fullWidth
                                    onChange={handleChangeSelect}
                                    inputProps={{
                                        area: 'area',
                                    }}
                                >
                                    {distritos.map((distrito,index) =>{
                                        return(
                                            <option value={distrito}>{distrito}</option>
                                        );
                                    })}
          
                                </Select>

                                </Grid>
                            </Grid>
                            <Grid item xs={12}>
                                <Paper className={classes.paper} elevation={0}>
                                    <h3>Description</h3>
                                    <textarea placeholder="Description" id="description" value = {description} onChange={changeDescription} className={classes.textarea} maxLength={500}></textarea>
                                </Paper>
                            </Grid>
                            <Grid item xs={12}>
                                    <input type="file" class="form-control-file" id="exampleFormControlFile1" onChange={onDrop2}/>
                            </Grid>
                        </Grid>
                        <Grid item xs={7}>
                            {
                            marks.map((marks,idx) => {
                                if(page-1 == idx){
                                    return(
                                        <div key={idx}>
                                            <Grid container justify="center" alignItems="center" direction="column">
                                                <Grid container>
                                                    <Grid item xs={4}>
                                                        <h4 className={classes.nomargin}>Marker name</h4>
                                                        <input type="text" placeholder="Marker name" value={marks.name} onChange={handleChangeName(idx)}></input>
                                                        <FormControlLabel
                                                        control={<Checkbox
                                                        checked={marks.stopover}
                                                        onChange={handleChangeStopat(idx)}
                                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                                        />}
                                                        label="It's a stop?"
                                                        labelPlacement="start"
                                                        />
                                                    </Grid>
                                                    <Grid item xs={2}>
                                                        
                                                            <IconButton className={classes.deletebutton} onClick={deleteMarker(idx)}>
                                                                <DeleteIcon/>
                                                            </IconButton>
                                                            <Button variant="contained" onClick={deleteMarkS}>Delete all markers</Button>
                                                        </Grid>
                                                </Grid>
                                                <Grid container>
                                                    
                                                    <textarea placeholder="Marker description" id="description" value={marks.content} onChange={handleChangeDesc(idx)} className={classes.textarea2} maxLength={500}></textarea>
                                                </Grid>
                                                    
                                            </Grid>
                                    </div>
                                );
                                }
                                else{
                                    return(null);
                                }
                            })}
                            <Pagination count={marks.length} page={page} onChange={handleChange} className={classes.pagi} boundaryCount={2}/>
                        </Grid>
                    </Grid>
                    
                    
                </div>
            </div>
        );
    }