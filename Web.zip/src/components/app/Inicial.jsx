import React from "react";
import './Inicial.css';
import history from '../../history';
import Content from "../utils/Contenthome";
import { makeStyles } from '@material-ui/core/styles';
import { Redirect } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
    ul: {listStyleType: "none", 
                    margin: "0",
                    padding: "0",
                    overflow: "hidden",
                    backgroundColor:"#333",
                    position: "sticky", 
                    width: "100%"},
    li :{float: "left",
        fontSize:"1.2em"},

    liright : {float: "right",
    fontSize:"1.2em"},
    a :{
            display: "block",
            color: "white",
            textAlign: "center",
            padding: "14px 16px",
            textDecoration: "none",
            fontFamily: [
                '-apple-system',
                'BlinkMacSystemFont',
                '"Segoe UI"',
                'Roboto',
                'Oxygen',
                'Ubuntu',
                'Cantarell', 
                'Fira Sans', 
                'Droid Sans',
                'Helvetica Neue',
                'sans-serif',
              ],
              "&:hover": {
                backgroundColor: "#111",
              },
          }
  }));

function redirect(){
    history.push("/home");
}

export default function Inicial(){

    const classes = useStyles();

    if(localStorage.getItem("key") == null){
       return (
            <div className="app">
                <header className="headerapp">
                    <div className="headerapp-text">
                    <a>Come and discover our trails</a>
                    </div>
                </header>
                <div className="barapp">
                    <ul className={classes.ul}>
                        <li className={classes.li}><a className={classes.a} href="/">Home</a></li>
                        <li className={classes.li}><a className={classes.a} href="login">Quizz</a></li>
                        <li className={classes.li}><a className={classes.a} href="login">Trail</a></li>
                        <li className={classes.liright}><a className={classes.a} href="login">Login</a></li>
                        <li className={classes.liright}><a className={classes.a} href="register">Sign up</a></li>
                    </ul>
                </div>
                <div className="contentapp">
                        <Content/>
                </div>
            </div>
        );
       }
       else{
            return(<Redirect to='/home' />);
       }
}
