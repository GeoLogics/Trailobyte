import React from "react";
import history from '../../history';

import Inicial from "./Inicial";
import login from "../Login/login";
import logout from '../logout/logout';
import register from '../register/register';
import Quizz from '../quizz/quizz'
import QuizzDo from '../quizz/quizzDo'
import QuizzPost from '../quizz/quizzPost'
import { Router, Route, Switch } from 'react-router-dom';
import PostTrail from '../maps/PostTrail';
import QMCPost from '../quizz/QMCPost';
import QOPost from '../quizz/QOPost';
import QTFPost from '../quizz/QTFPost';
import Trail from '../trail/Trail';
import TrailList from '../trail/TrailList';
import Home from '../Home/Home';
import settings from "../settings/settings";
import backoffice from "../backOffice/MainMenu";
import ViewTrail from "../maps/ViewTrailteste";
import {PrivateRoute} from "../utils/PrivateRoute";


export default class App extends React.Component {

    render() {
    return(
    <Router history={history}>
      <Switch>
      <Route exact path={"/"} component={Inicial} />
      <Route path={"/login"} component={login} />
      <PrivateRoute path={"/logout"} component={logout}/>
      <Route path={"/register"} component={register} />
      <PrivateRoute path={"/home"} component={Home} />
      <PrivateRoute path={"/trail"} component={Trail}/>
      <PrivateRoute path={"/postTrail"} component={PostTrail} />
      <PrivateRoute path={"/view/:mapid"} component={ViewTrail}/>
      <PrivateRoute path={"/viewlist"} component={TrailList}/>
      <PrivateRoute path={"/askquizz"} component={Quizz}/>
      <PrivateRoute path={"/quizz/create"} component={QuizzPost}/>
      <PrivateRoute path={"/quizz/createQMC"} component={QMCPost}/>
      <PrivateRoute path={"/quizz/createQO"} component={QOPost}/>
      <PrivateRoute path={"/quizz/createQTF"} component={QTFPost}/>
      <PrivateRoute path={"/quizz/start"} component={QuizzDo}/>
      <PrivateRoute path={"/settings"} component={settings}/>
      <PrivateRoute path={"/backoffice"} component={backoffice}/>
      </Switch>
    </Router>
        );
    }
}