import React,{ Component } from "react";
import './QuizzQO.css';

var optionsByOrder= [];

var body = document.body,
  html = document.documentElement;

var height = Math.max(body.scrollHeight, body.offsetHeight,
  html.clientHeight, html.scrollHeight, html.offsetHeight);

export default class QuizzQO extends Component{
    
    constructor(props){
        super(props);
        this.state = {
            option1Order:1,
            option2Order:2,
            option3Order:3,
            option4Order:4,
            option5Order:5,
            optionsByOrder: [],
            error:'',
            question: props.question,
            number: props.nr,
        };


        this.option1OrderChange = this.option1OrderChange.bind(this);
        this.option2OrderChange = this.option2OrderChange.bind(this);
        this.option3OrderChange = this.option3OrderChange.bind(this);
        this.option4OrderChange = this.option4OrderChange.bind(this);
        this.option5OrderChange = this.option5OrderChange.bind(this);
        this.DefaultError = this.DefaultError.bind(this);
    }

    

    DefaultError() {
        this.setState({ error: '' });
    }


    option1OrderChange(event){
        this.setState({option1Order: event.target.value});
    };

    option2OrderChange(event){
        this.setState({option2Order: event.target.value});
    };

    option3OrderChange(event){
        this.setState({option3Order: event.target.value});
    };

    option4OrderChange(event){
        this.setState({option4Order: event.target.value});
    };

    option5OrderChange(event){
        this.setState({option5Order: event.target.value});
    };

    enunciatedShow(){
        return this.state.question.enunciated;
    }

    optionShow(x){
        return this.state.question.options.options[x];
    }

    questionShow(){
        return this.state.question.question;
    }


    setOrder(option, optionOrder){
        this.state.optionsByOrder[optionOrder-1] = option
     }


    activate = () => {
        document.getElementById('getAnswer').click();
    }

    disable = () => {
        document.getElementById('getAnswer').disabled = 'disabled';
    }

    getAnwser = () => {

        
            this.setOrder("option1", this.state.option1Order);
            this.setOrder("option2", this.state.option2Order);
            this.setOrder("option3", this.state.option3Order);
            this.setOrder("option4", this.state.option4Order);
            this.setOrder("option5", this.state.option5Order);
            var temp = [this.state.number,this.state.optionsByOrder];
            this.props.parentCallback(temp);
            this.disable();
            window.scrollBy(0,height+60);

    };

    isValid () {

     var bool = true;
        for(var i=0; i < 5; i++){
            for(var j=0; i<5; j++){
                if(optionsByOrder[i] == optionsByOrder[j] && i!=j){
                    bool = false;
                }
            }
        }

        /*if(bool){
            this.getAnwser();
        }else{
            alert('not all diferent')
        }*/
        return bool;
    }

    renderIf(){
        if(this.questionShow() != '')
        return(
            <div className="question">
                <a id = "AQuizzQ">Question</a>
                <div id="questionDoQO">
                    
                    <a id = "textIDQ1">{this.questionShow()}</a>
                </div>
            </div>
        );
    }

    render(){
        return(
            <div className="QuizzQO">

                
                <a id = "AQuizzE">Enuncited</a>
                <div id="enunciatedDoQO">
                    <a className="enunciated">
                        {this.state.question.enunciated}
                    </a>     
                </div>

                <div >
                    {this.renderIf()}
                </div>
                <p>
                    
                </p>


                <div className="option1">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" value = {this.state.option1Order} onChange={this.option1OrderChange}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(0)}</a>
                    </div>
                </div>

                <div className="option2">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" value = {this.state.option2Order} onChange={this.option2OrderChange}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(1)}</a>
                    </div>
                </div>

                <div className="option3">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" value = {this.state.option3Order} onChange={this.option3OrderChange}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(2)}</a>
                    </div>
                </div>

                <div className="option4">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" value = {this.state.option4Order} onChange={this.option4OrderChange}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(3)}</a>
                    </div>
                </div>

                <div className="option5">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" value = {this.state.option5Order} onChange={this.option5OrderChange}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(4)}</a>
                    </div>
                </div>
                <div className="QOsubmit">
                     <input type="submit" onClick ={this.getAnwser} value = "Next" id="getAnswer"/>
                </div>
        </div>
        );
    }
}
/**                <div className="enunciatedQOQuizz">
                <a id = "AQuizzE">Enuncited</a>
                    <textarea name="myTextBox" cols="131" rows="5"  value = {this.enunciatedShow()} readOnly>
        
                    </textarea>     
                </div>

                <div className="question">
                <a id = "AQuizzQ">Question</a>
                    <input type="text" id="QOQuizz" value = {this.questionShow()} readOnly/>
                </div> */