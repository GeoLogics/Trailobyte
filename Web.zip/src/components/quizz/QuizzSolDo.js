import React,{ Component } from "react";
import { withRouter } from "react-router-dom";
import history from '../../history';

import './quizzDo.css';
import QuizzSolQMC from "./QuizzSolQMC";
import QuizzSolQO from "./QuizzSolQO";
import QuizzSolQTF from "./QuizzSolQTF";


var questionQMC = {//enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   enunciated:"Qual é a espessura média da crosta continental?",

                   //question: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   question:"Escolha a opcao correta",

                   
                   
                   optionA: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionB: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   /*optionC: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionD: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   *//*
                   optionA:"7 km",
                   optionB:"35 km",*/
                   optionC:"1 km",
                   optionD:"100 km",
                   correctOption:"B",
                   id:5
                };

var questionQO = {
                //enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                enunciated: "Ordena as frases de modo a reconstituir a sequência cronológica dos acontecimentos associados a um ciclo oceânico completo (implica o processo de abertura e fecho de um oceano, com a consequente formação de uma cadeia orogénica).",
                question: "Ordena as frases",
                options: {
                    options: [/*"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
                                "Início do alargamento de um oceano primitivo.", */
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "Formação de cadeias montanhosas de colisão.",
                                "Instalação de vulcanismo andesítico em margens continentais ativas.",
                                "Estiramento de crosta continental."]
                },
                byOrder:{
                    byOrder:["option5", "option2", "option1", "option4", "option3"]
                },
                id:""
            };

 //"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
var questionQTF = {
                enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                question: "Classifique como verdadeira ou falsa cada uma das seguintes afirmações, relativas a características da Lua.",
                questionsList: {
                    questions: [/*"Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",
                                  "Terrae (os continentes) são zonas claras, ricas em minerais félsicos.",*/
                                  "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                  "A erosão tem reduzido o número de crateras de impacto nos mares.",
                                  "Maria (os mares) são zonas escuras, ricas em minerais ferromagnesianos."]
                },
                answersList:{
                    answersList:["T", "T", "F", "T"]
                },
                id:1,
                numberOfQuestions:4
            };
//"Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",


var randomArray=[];

var arrayOfQMC=[0,0,0,0];
var arrayOfQO=[0,0,0,0];
var arrayOfQTF=[0,0];


class quizzSolDo extends Component{
    constructor(props){
        super(props);
        this.state={
            questionQMC: [],
            questionQO: [],
            questionQTF: [],
        }
    }

    DefaultError() {
        this.setState({ error: '' });
    }


    gotoApp(){
        history.goBack();
    }

    async componentDidMount(){
        //aqui pedir questoes a datastore

        const qmc = localStorage.getItem("arrayOfQMC");
        const qo = localStorage.getItem("arrayOfQO");
        const qtf = localStorage.getItem("arrayOfQTF");

        arrayOfQMC= JSON.parse(qmc);
        arrayOfQO= JSON.parse(qo);
        arrayOfQTF= JSON.parse(qtf);

        /*if(arrayOfQMC.length === 4)
            console.log('success QMC');
        if(arrayOfQO.length === 4)
            console.log('success QO');
        if(arrayOfQTF.length === 2)
            console.log('success QTF');*/
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO



        for(var i = 0 ; i <arrayOfQMC.length ; i++){
            await this.askquizz(arrayOfQMC[i], 'QMC')
        }

        for(var i = 0 ; i <arrayOfQO.length ; i++){
            await this.askquizz(arrayOfQO[i], 'QO')
        }

        for(var i = 0 ; i <arrayOfQTF.length ; i++){
            await this.askquizz(arrayOfQTF[i], 'QTF')
        }




//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
/*        for(var i = 0 ; i <4 ; i++){
            this.setState(prevState => ({
                questionQMC: [...prevState.questionQMC, questionQMC]
            }))
        }

        for(var i = 0 ; i <4 ; i++){
            this.setState(prevState => ({
                questionQO: [...prevState.questionQO, questionQO]
            }))
        }

        for(var i = 0 ; i <2 ; i++){
            this.setState(prevState => ({
                questionQTF: [...prevState.questionQTF, questionQTF]
            }))
        }*/
    }

     askquizz(i, type){
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var headers = new Headers();
        headers.append('username', username);
        headers.append('Authorization','Bearer '+key,);
        headers.append('Accept', 'application/json');
         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPG' + type + '1OP/'+ i, {
            method: 'GET',
            headers: headers,
        })
        .then(async (response) => {
            var temp = await response.json();

            if(type == 'QMC'){
                this.setState(prevState => ({
                    questionQMC: [...prevState.questionQMC, temp]
                  }))
            }else if (type == 'QO'){
                var startQO=[0,0,0,0,0];
                
                this.setState(prevState => ({
                    questionQO: [...prevState.questionQO, temp]
                  }))
            }else{
                var startQTF=['Z', 'Z', 'Z', 'Z'];
                this.setState(prevState => ({
                    questionQTF: [...prevState.questionQTF, temp]
                  }))
            }
        })
        .catch(error => alert("Server not available"));
    }

    callbacktest = () => {
        /*var result = 0;
        this.refs.Question0.activate();
        this.refs.Question1.activate();
        this.refs.Question2.activate();
        this.refs.Question3.activate();
        this.refs.Question4.activate();
        this.refs.Question5.activate();
        this.refs.Question6.activate();
        this.refs.Question7.activate();
        this.refs.Question8.activate();
        this.refs.Question9.activate();*/

        //localStorage.setItem("score",5);
        history.push("/quizz/finish");
        
    }








    render(){
        return(
            <div className="quizzDo">
                <button onClick={this.gotoApp}>Back</button>
                <h1>Quizz</h1>
                <div className="allQuestions">
                    {this.state.questionQMC.map((question,idx) => {
                        return(
                            <div key={"QMC_" + idx}>
                                <h2>Solution {idx + 1}</h2>
                                <QuizzSolQMC question = {question} nr={idx}  ref ={`Question${idx}`}></QuizzSolQMC>
                            </div>
                        );
                    })}
                    {this.state.questionQO.map((question,idx) => {
                        return(
                            <div key={"QO_" + idx}>
                                <h2>Solution {idx + this.state.questionQMC.length + 1}</h2>
                                <QuizzSolQO question = {question} nr={idx}  ref ={`Question${idx+this.state.questionQMC.length}`} ></QuizzSolQO>
                            </div>
                        );
                    })}
                    {this.state.questionQTF.map((question,idx) => {
                        return(
                            <div key={"QTF_" + idx}>
                                <h2>Solution {idx + this.state.questionQMC.length + this.state.questionQO.length + 1}</h2>
                                <QuizzSolQTF question = {question} nr={idx}  ref ={`Question${idx+this.state.questionQMC.length + this.state.questionQO.length}`}></QuizzSolQTF>
                            </div>
                        );
                    })}

                   <input type="submit" onClick ={this.callbacktest} value = "Submit"/>         
                </div>
            
            </div>
        );
    }
}
export default withRouter(quizzSolDo);