import React,{ Component } from "react";
import './QuizzQMC.css';

var body = document.body,
                html = document.documentElement;
              
var height = Math.max(body.scrollHeight, body.offsetHeight,
            html.clientHeight, html.scrollHeight, html.offsetHeight);


export default class QuizzQMC extends Component{
    
    constructor(props){
        super(props);
        this.state = {
            question: props.question,
            number: props.nr,
        };
    }

    enuncitedShow(){
        return this.state.question.enunciated;
    }

    questionShow(){
        return this.state.question.question;
    }

    optionAShow(){
        return this.state.question.optionA;
    }

    optionBShow(){
        return this.state.question.optionB;
    }

    optionCShow(){
        return this.state.question.optionC;
    }

    optionDShow(){
        return this.state.question.optionD;
    }

    activate = () => {
        document.getElementById('getAnswer').click();
    }

    disable = () => {
        document.getElementById('getAnswer').disabled = 'disabled';
    }

    getAnwser = () => {
        var radios = document.getElementsByName(this.state.number);
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].checked) {
                var temp = [this.state.number,radios[i].value];
                this.props.parentCallback(temp);
                break;
            }
        }
        //this.disable();
        window.scrollBy(0,height+60);
        //alert("/" + 3);
    };

    renderIf(){
        if(this.questionShow() != '')
        return(
            <div className="question">
                <a id = "AQuizzQ">Question</a>
                <div id="questionDoQMC">
                    
                    <a id = "textIDQ1">{this.questionShow()}</a>
                </div>
            </div>
        );
    }

    render(){
        return(
            <div className="QuizzQMC">
            <a id = "AQuizzE">Enuncited</a>
            <div id="enunciatedDoQMC">
                <a className="enunciated">
                    {this.state.question.enunciated}
                </a>     
            </div>

            <div >
                {this.renderIf()}
            </div>
            <p>
                
            </p>

            <div className="optionA">
                <a id = "opt">OptionA</a>
                <p>
                    
                </p>
                <div>
                    <div id="radioGeneral">
                        <input id ="radio" type="radio" value="A" name= {this.state.number} />
                    </div>
                    <div id="optionDoQMC">
                        <a id = "textIDQ">{this.optionAShow()}</a>
                    </div>
                </div>
            </div>

            <div className="optionB">
                <a id = "opt">OptionB</a>
                <p>
                    
                </p>
                <div>
                    <div id="radioGeneral">
                        <input id ="radio" type="radio" value="B" name={this.state.number} />
                    </div>
                    <div id="optionDoQMC">
                        <a id = "textIDQ">{this.optionBShow()}</a>
                    </div>
                </div>
            </div>

            <div className="optionC">
                <a id = "opt">OptionC</a>
                <p>
                    
                </p>
                <div>
                    <div id="radioGeneral">
                        <input id ="radio" type="radio" value="C" name={this.state.number} />
                    </div>
                    <div id="optionDoQMC">
                        <a id = "textIDQ">{this.optionCShow()}</a>
                    </div>
                </div>
            </div>

            <div className="optionD">
                <a id = "opt">OptionD</a>
                <p>

                </p>
                <div>
                    <div id="radioGeneral">
                        <input id ="radio" type="radio" value="D" name={this.state.number} />
                    </div>
                    <div id="optionDoQMC">
                        <a id = "textIDQ">{this.optionDShow()}</a>
                    </div>
                </div>
            </div>

            <div className="QMCsubmit">
                <input type="submit" onClick ={this.getAnwser} value = "Next" id="getAnswer"/>
            </div>
        </div>
        );
    }
}
/*
<input id = "textIDQ1" type="text" value = {this.questionShow()} readOnly/>


<input id = "textIDQ" type="text" value = {this.optionDShow()} readOnly/>
*/