import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import history from '../../history';
import { render } from 'react-dom';
//import NavBar from "../utils/navbar";
import './quizzFinish.css';


class Quizz extends Component {

    constructor(){
        super();
        this.state = {
            result: 0,
        };


    }


    componentWillMount(){
        const result = localStorage.getItem("score");

        this.setState({result: result});
    }

    render2(){


        //const result = localStorage.getItem("score");

        if(this.state.result >=5){
            return this.renderGreen(this.state.result)
        }else{
            console.log('entrouuuuuuuuu');
            return this.renderRed(this.state.result)
        }
        
    }

    goToMainQuizz = () => {
        history.push("/askquizz");
    }

    goToSol = () =>{
        history.push("/quizz/Sol");
    }

    renderGreen(result){
        return (

            <div className='quizzFinish'>
                <div  id = 'cenas'>
                    <a id = 'greenRes'> Result : {result}/10</a>

                    <input type="submit" onClick ={this.goToMainQuizz} value = "Finish" id = 'finish'/>
                    <input type="submit" onClick ={this.goToSol} value = "Solutions" id = 'sol'/>  
                </div>
            </div>

        );
    }

    renderRed(result){
        return (

            <div className='quizzFinish'>
                <div id = 'cenas'>
                    <a id = 'redRes'>Result : {result}/10</a>

                    <input type="submit" onClick ={this.goToMainQuizz} value = "Finish" id = 'finish'/> 
                    <input type="submit" onClick ={this.goToSol} value = "Solutions" id = 'sol'/> 
                </div>
            </div>

        );
    }

    render(){
        return(
            <div className='quizzFinish'>
                {this.render2()} 
            </div>
        );
    }
}

    export default withRouter(Quizz);