import React,{ Component } from "react";
import history from '../../history';
import './QuizzSolQTF.css';

var body = document.body,
  html = document.documentElement;

var height = Math.max(body.scrollHeight, body.offsetHeight,
  html.clientHeight, html.scrollHeight, html.offsetHeight);

export default class QuizzSolQTF extends Component{

    constructor(props){
        super(props);
        this.state = {
            answersList: [],
            answer1:'',
            answer2:'',
            answer3:'',
            answer4:'',
            error:'',
            question: props.question,
            number: props.nr,
        };
    }

    DefaultError() {
        this.setState({ error: '' });
    }


    enuncitedShow(){
        return this.state.question.enunciated;
    }

    questionShow(x){
        return this.state.question.questionsList.questions[x];
    }

    questionXShow(){
        return this.state.question.question;
    }

    radioShow(valueOf, id){
        if(this.state.question.answersList.answersList[id] == valueOf){
            console.log(this.state.question.answersList.answersList[id] == valueOf);
            return true;
        }else{
            return false;
        }
        
    }

    renderIf(){
        if(this.questionXShow() != '')
        return(
            <div className="question">
                <a id = "AQuizzQ">Question</a>
                <div id="questionDoQTF">
                    
                    <a id = "textIDQ1">{this.questionXShow()}</a>
                </div>
            </div>
        );
    }

    render(){
        return(
            <div className="QuizzQTF">

                <a id = "AQuizzE">Enuncited</a>
                <div id="enunciatedDoQTF">
                    <a className="enunciated">
                        {this.state.question.enunciated}
                    </a>     
                </div>

                <div >
                    {this.renderIf()}
                </div>
                <p>
                    
                </p>


                <div className="question1">
                    <div id="radioGeneral">
                        <input id="radioT" type="radio" /*value="T" name="radAnswer1" */
                        checked= {this.radioShow("T", 0)} /><a id = "T">T</a>
                        <input type="radio" /*value="F" name="radAnswer1"*/ 
                        checked= {this.radioShow("F", 0)} /><a id = "F">F</a>
                    </div>
                    <div id = "optionDoQTF">
                        <a id = "textIDQ">{this.questionShow(0)}</a>
                    </div>
                </div>

                <div className="question2">
                    <div id="radioGeneral">
                        <input id="radioT" type="radio" /*value="T" name="radAnswer2"*/ 
                        checked= {this.radioShow("T", 1)} /><a id = "T">T</a>
                        <input type="radio" /*value="F" name="radAnswer2" */
                        checked= {this.radioShow("F", 1)} /><a id = "F">F</a>
                    </div>
                    <div id = "optionDoQTF">
                        <a id = "textIDQ">{this.questionShow(1)}</a>
                    </div>
                </div>

                <div className="question3">
                    <div id="radioGeneral">
                        <input id="radioT" type="radio" /*value="T" name="radAnswer3"*/ 
                        checked= {this.radioShow("T", 2)} /><a id = "T">T</a>
                        <input type="radio" /*value="F" name="radAnswer3"*/ 
                        checked= {this.radioShow("F", 2)} /><a id = "F">F</a>
                    </div>
                    <div id = "optionDoQTF">
                        <a id = "textIDQ">{this.questionShow(2)}</a>
                    </div>
                </div>

                <div className="question4">
                    <div id="radioGeneral">
                        <input id="radioT" type="radio"  /*name="radAnswer4" value= 'T'*/ 
                        checked= {this.radioShow("T", 3)} /><a id = "T">T</a>
                        <input type="radio"  /*name="radAnswer4" value= 'F'*/ 
                        checked= {this.radioShow("F", 3)} /><a id = "F">F</a>
                    </div>
                    <div id = "optionDoQTF">
                        <a id = "textIDQ">{this.questionShow(3)}</a>
                    </div>
                </div>
            </div>
        );
    }

}