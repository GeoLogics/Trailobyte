import React,{ Component } from "react";
import './QuizzSolQO.css';

var optionsByOrder= [];

var body = document.body,
  html = document.documentElement;

var height = Math.max(body.scrollHeight, body.offsetHeight,
  html.clientHeight, html.scrollHeight, html.offsetHeight);

export default class QuizzSolQO extends Component{
    
    constructor(props){
        super(props);
        this.state = {
            option1Order:1,
            option2Order:2,
            option3Order:3,
            option4Order:4,
            option5Order:5,
            error:'',
            question: props.question,
            number: props.nr,
        };
    }



    enunciatedShow(){
        return this.state.question.enunciated;
    }

    optionShow(x){
        return this.state.question.options.options[x];
    }

    questionShow(){
        return this.state.question.question;
    }


    getCorrectOrder(j){


        try{
            for(var i =0; i < 5; i++){
                //console.log('byOrder: '+this.state.byOrder[j]);
                var cenas = this.state.question.byOrder.byOrder[i];
                cenas = cenas.replace(/[^\d]/g, '');
                cenas=parseInt(cenas);
                if(cenas==(j+1)){
                    return (i+1).toString();
                }
                
            }
            return (0).toString();
        }catch{
            return (0).toString();
        }

    }


    renderIf(){
        if(this.questionShow() != '')
        return(
            <div className="question">
                <a id = "AQuizzQ">Question</a>
                <div id="questionDoQO">
                    
                    <a id = "textIDQ1">{this.questionShow()}</a>
                </div>
            </div>
        );
    }




    render(){
        return(
            <div className="QuizzQO">

                
                <a id = "AQuizzE">Enuncited</a>
                <div id="enunciatedDoQO">
                    <a className="enunciated">
                        {this.state.question.enunciated}
                    </a>     
                </div>

                <div >
                    {this.renderIf()}
                </div>
                <p>
                    
                </p>


                <div className="option1">
                    <input type="number" placeholder="Order" id = {this.state.number} className={"orderOfPostQuizz"} min="1" max="5" 
                    value = {this.getCorrectOrder(0)} onChange={this.option1OrderChange} disabled={true}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(0)}</a>
                    </div>
                </div>

                <div className="option2">
                    <input type="number" placeholder="Order" id = {this.state.number} className= {"orderOfPostQuizz"} min="1" max="5" 
                    value = {this.getCorrectOrder(1)} onChange={this.option2OrderChange} disabled={true}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(1)}</a>
                    </div>
                </div>

                <div className="option3">
                    <input type="number" placeholder="Order" id = {this.state.number} className={"orderOfPostQuizz"} min="1" max="5" 
                    value = {this.getCorrectOrder(2)} onChange={this.option3OrderChange} disabled={true}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(2)}</a>
                    </div>
                </div>

                <div className="option4">
                    <input type="number" placeholder="Order" id = {this.state.number} className={"orderOfPostQuizz"} min="1" max="5" 
                    value = {this.getCorrectOrder(3)} onChange={this.option4OrderChange} disabled={true}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(3)}</a>
                    </div>
                </div>

                <div className="option5">
                    <input type="number" placeholder="Order" id = {this.state.number}  className={"orderOfPostQuizz"} min="1" max="5" 
                    value = {this.getCorrectOrder(4)} onChange={this.option5OrderChange} disabled={true}/>
                    <div id = "optionDoQO">
                        <a id = "textIDQ">{this.optionShow(4)}</a>
                    </div>
                </div>
        </div>
        );
    }
}
