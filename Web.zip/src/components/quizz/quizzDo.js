import React,{ Component } from "react";
import { withRouter } from "react-router-dom";
import history from '../../history';

import './quizzDo.css';
import QuizzQMC from "./QuizzQMC";
import QuizzQO from "./QuizzQO";
import QuizzQTF from "./QuizzQTF";


var questionQMC = {//enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   enunciated:"Qual é a espessura média da crosta continental?",

                   //question: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",

                   question:"Escolha a opcao correta",

                   
                   
                   optionA: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionB: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   /*optionC: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   optionD: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                   *//*
                   optionA:"7 km",
                   optionB:"35 km",*/
                   optionC:"1 km",
                   optionD:"100 km",
                   correctOption:"B",
                   id:5
                };

var questionQO = {
                //enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                enunciated: "Ordena as frases de modo a reconstituir a sequência cronológica dos acontecimentos associados a um ciclo oceânico completo (implica o processo de abertura e fecho de um oceano, com a consequente formação de uma cadeia orogénica).",
                question: "Ordena as frases",
                options: {
                    options: [/*"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
                                "Início do alargamento de um oceano primitivo.", */
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "Formação de cadeias montanhosas de colisão.",
                                "Instalação de vulcanismo andesítico em margens continentais ativas.",
                                "Estiramento de crosta continental."]
                },
                byOrder:{
                    byOrder:["option5", "option2", "option1", "option4", "option3"]
                },
                id:""
            };

 //"Início de subdução de crosta oceânica, geralmente mais antiga e mais densa." ,
var questionQTF = {
                enunciated: "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                question: "Classifique como verdadeira ou falsa cada uma das seguintes afirmações, relativas a características da Lua.",
                questionsList: {
                    questions: [/*"Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",
                                  "Terrae (os continentes) são zonas claras, ricas em minerais félsicos.",*/
                                  "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                "A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas. /////////////////////////////// A Lua é o satélite da Terra que foi fortemente bombardeado por meteoritos no início da sua história, quando, por debaixo de uma crosta lunar primitiva, existia um magma lunar abundante. Actualmente, a superfície lunar apresenta zonas escuras resultantes do preenchimento de bacias de impacto com magma basáltico solidificado, datado de aproximadamente 3000 M.a. As zonas claras apresentam um maior número de crateras de impacto do que as zonas escuras e são mais antigas do que estas.",
                                  "A erosão tem reduzido o número de crateras de impacto nos mares.",
                                  "Maria (os mares) são zonas escuras, ricas em minerais ferromagnesianos."]
                },
                answersList:{
                    answersList:["T", "T", "F", "T"]
                },
                id:1,
                numberOfQuestions:4
            };
//"Há mais de 3000 M.a., a Lua era um planeta geologicamente activo.",


var randomArray=[];

var arrayOfQMC=[];
var arrayOfQO=[];
var arrayOfQTF=[];


class quizzDo extends Component{
    constructor(props){
        super(props);
        this.state={
            questionQMC: [],
            questionQO: [],
            questionQTF: [],
            answerQMC:[],
            answerQO: [],
            answerQTF: [],
            result: '',

            maxQMC: 4,
            maxQO: 4,
            maxQTF: 2,
        }
    }

    DefaultError() {
        this.setState({ error: '' });
    }


    validateQOs(i){
        var bol1= false;
        var bol2= false;
        var bol3= false;
        var bol4= false;
        var bol5= false;

        if(this.state.questionQO[i].byOrder.byOrder[0] == this.state.answerQO[i][0])
            bol1=true;

        if(this.state.questionQO[i].byOrder.byOrder[1] == this.state.answerQO[i][1])
            bol2=true;

        if(this.state.questionQO[i].byOrder.byOrder[2] == this.state.answerQO[i][2])
            bol3=true;

        if(this.state.questionQO[i].byOrder.byOrder[3] == this.state.answerQO[i][3])
            bol4=true;

        if(this.state.questionQO[i].byOrder.byOrder[4] == this.state.answerQO[i][4])
            bol5=true;

            console.log('QO1 answer VAL: ' + this.state.answerQO[i][0]);
            console.log('QO2 answer VAL: ' + this.state.answerQO[i][1]);
            console.log('QO3 answer VAL: ' + this.state.answerQO[i][2]);
            console.log('QO4 answer VAL: ' + this.state.answerQO[i][3]);
            console.log('QO5 answer VAL: ' + this.state.answerQO[i][4]);

        return bol1 && bol2 && bol3 && bol4 && bol5;
    }

    validateQTFs(i){
        var q1=false;
        var q2=false;
        var q3=false;
        var q4=false;

        if(this.state.questionQTF[i].answersList.answersList[0] == this.state.answerQTF[i][0])
            q1=true;

        if(this.state.questionQTF[i].answersList.answersList[1] == this.state.answerQTF[i][1])
            q2=true;

        if(this.state.questionQTF[i].answersList.answersList[2] == this.state.answerQTF[i][2])
            q3=true;

        if(this.state.questionQTF[i].answersList.answersList[3] == this.state.answerQTF[i][3])
            q4=true;

            console.log('QTF1 answer: ' + this.state.answerQTF[i][0]);
            console.log('QTF2 answer: ' + this.state.answerQTF[i][1]);
            console.log('QTF3 answer: ' + this.state.answerQTF[i][2]);
            console.log('QTF4 answer: ' + this.state.answerQTF[i][3]);

        return q1 && q2 && q3 && q4;
    }

    validateQMC(i){
        if(this.state.questionQMC[i].correctOption == this.state.answerQMC[i]){
            console.log('QMC answer: ' + this.state.answerQMC[i]);
            return true;
        }
        return false;
    }

    gotoApp(){
        history.goBack();
    }

   /* componentWillMount(){
        this.askquizzQMC(1);
        this.askquizzQO(1);
        this.askquizzQTF(1);
    }*/

    async componentWillMount(){

        //DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO

        await this.getNumberOfQuestions('QMC');
        await this.getNumberOfQuestions('QO');
        await this.getNumberOfQuestions('QTF');

        this.genrateRandoms();
        this.set();

        localStorage.removeItem("arrayOfQMC");
        localStorage.setItem("arrayOfQMC",JSON.stringify(arrayOfQMC));

        localStorage.removeItem("arrayOfQO");
        localStorage.setItem("arrayOfQO",JSON.stringify(arrayOfQO));

        localStorage.removeItem("arrayOfQTF");
        localStorage.setItem("arrayOfQTF",JSON.stringify(arrayOfQTF));

        console.log('arrayOfQMC.length ' + arrayOfQMC.length);
        for(var i = 0 ; i <arrayOfQMC.length ; i++){
            console.log('QMC i: ' + i);
            await this.askquizz(arrayOfQMC[i], 'QMC')
        }

        for(var i = 0 ; i <arrayOfQO.length ; i++){
            await this.askquizz(arrayOfQO[i], 'QO')
        }

        for(var i = 0 ; i <arrayOfQTF.length ; i++){
            await this.askquizz(arrayOfQTF[i], 'QTF')
        }


    }

    async componentDidMount(){
        //aqui pedir questoes a datastore


//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO
//DESCOMENTAR ISTO




//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
//COMENTAR ISTO
 /*       var startQMC = 'Z'
        var startQO=['option0', 'option0', 'option0', 'option0', 'option0'];
        var startQTF=['Z', 'Z', 'Z', 'Z'];

        for(var i = 0 ; i <arrayOfQMC.length ; i++){
            this.setState(prevState => ({
                questionQMC: [...prevState.questionQMC, questionQMC],
                answerQMC: [...prevState.answerQMC, startQMC]
            }))
        }

        for(var i = 0 ; i <arrayOfQO.length ; i++){
            this.setState(prevState => ({
                questionQO: [...prevState.questionQO, questionQO],
                //answerQO: [],
                answerQO: [...prevState.answerQO, startQO],
            }))
        }

        for(var i = 0 ; i <arrayOfQTF.length ; i++){
            this.setState(prevState => ({
                questionQTF: [...prevState.questionQTF, questionQTF],
                answerQTF: [...prevState.answerQTF, startQTF],
            }))
        }*/
    }

     askquizz(i, type){
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var headers = new Headers();
        headers.append('username', username);
        headers.append('Authorization','Bearer '+key,);
        headers.append('Accept', 'application/json');
         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPG' + type + '1OP/'+ i, {
            method: 'GET',
            headers: headers,
        })
        .then(async (response) => {
            var temp = await response.json();
            console.log(temp)

            if(type == 'QMC'){
                this.setState(prevState => ({
                    questionQMC: [...prevState.questionQMC, temp],
                    answerQMC: [...prevState.answerQMC, 'Z'],
                  }))
            }else if (type == 'QO'){
                var startQO=[0,0,0,0,0];
                
                
                this.setState(prevState => ({
                    questionQO: [...prevState.questionQO, temp],
                    answerQO: [...prevState.answerQO, startQO],
                  }))
            }else{
                var startQTF=['Z', 'Z', 'Z', 'Z'];
                this.setState(prevState => ({
                    questionQTF: [...prevState.questionQTF, temp],
                    answerQTF: [...prevState.answerQTF, startQTF],
                  }))
            }
        })
        .catch(error => alert("Server not available"));
    }

    /*askquizzQO(i){
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var headers = new Headers();
        headers.append('username', username);
        headers.append('Authorization','Bearer '+key,);
        headers.append('Accept', 'application/json');

         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQO1OP/'+ i, {
            method: 'GET',
            headers: headers,
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({questionQO: [...this.state.questionQO,temp],
                answerQO: [...this.state.answerQO,temp.byOrder.byOrder],
            });
        })
        .catch(error => alert("Server not available"));

    }*/



     /*askquizzQTF(i){
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var headers = new Headers();
        headers.append('username', username);
        headers.append('Authorization','Bearer '+key,);
        headers.append('Accept', 'application/json');
         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/OPGQTF1OP/'+ i, {
            method: 'GET',
            headers: headers,
        })
        .then(async (response) => {
            var temp = await response.json();
            this.setState({questionQTF: [...this.state.questionQTF,temp],
                answerQTF: [...this.state.answerQTF,temp.answersList],
            });
        })
        .catch(error => alert("Server not available"));
    }*/

    callBackAnswersQMC = answerFromQuestion => {
        console.log('QMC anwser: ' + answerFromQuestion);
        var array = this.state.answerQMC;
        array[answerFromQuestion[0]] = answerFromQuestion[1];
        this.setState({answerQMC: array});
    }

    callBackAnswersQO = answerFromQuestion => {
        console.log('QO anwser: ' + answerFromQuestion);

        var array = this.state.answerQO;
        array[answerFromQuestion[0]] = answerFromQuestion[1];
        this.setState({answerQO: array});
        console.log(array);
    }

    callBackAnswersQTF = answerFromQuestion => {
        console.log('QTF anwser: ' + answerFromQuestion);
        var array = this.state.answerQTF;
        array[answerFromQuestion[0]] = answerFromQuestion[1];
        this.setState({answerQTF: array});
        console.log(array);
    }

    callbacktest = () => {
        var result = 0;
        this.refs.Question0.activate();
        this.refs.Question1.activate();
        this.refs.Question2.activate();
        this.refs.Question3.activate();
        this.refs.Question4.activate();
        this.refs.Question5.activate();
        this.refs.Question6.activate();
        this.refs.Question7.activate();
        this.refs.Question8.activate();
        this.refs.Question9.activate();
        

        for(var i = 0; i < arrayOfQMC.length; i++)
            if(this.validateQMC(i))
                result++;

        for(var i = 0; i < arrayOfQO.length; i++)
            if(this.validateQOs(i))
                result++;

        for(var i = 0; i < arrayOfQTF.length; i++)
            if(this.validateQTFs(i))
                result++;


        localStorage.removeItem("score");
        localStorage.setItem("score",result);

        history.push("/quizz/finish");
        
    }




    genrateRandoms(){

        var counterQMC =0;
        var counterQO =0;
        var counterQTF =0;

        randomArray=[];

        arrayOfQMC=[];
        arrayOfQO=[];
        arrayOfQTF=[];


        for(var i=0; i < 10; i++){
            //gerar random entre 0 e 2
            var randomNumber = Math.floor(Math.random() * 3);
            //adicionar a posicao i o random gerado

            if(randomNumber==0){
                if(counterQMC < this.state.maxQMC){
                    randomArray.push(randomNumber);
                    counterQMC++;
                }else{
                    i--;
                }
                
            }
            else if(randomNumber==1){
                if(counterQO < this.state.maxQO){
                    randomArray.push(randomNumber);
                    counterQO++;
                }else{
                    i--;
                }
            }
            else{
                if(counterQTF < this.state.maxQTF){
                    randomArray.push(randomNumber);
                    counterQTF++;
                }else{
                    i--;
                }
            }
        }

    }

    //recebe index do array
    translateIntToType(j){

        var i = randomArray[j];

        if(i==0){
            return "QMC";
        }else if(i==1){
            return "QO";
        }
        else{
            return "QTF";
        }
    }


    genareteIdOfQuestion(i){

        var type = this.translateIntToType(i);

        var bool = false;
        var randomNumber=0;

        if(type == "QMC"){

            while (!bool){
                randomNumber = Math.floor(Math.random() * this.state.maxQMC) + 1;
                if(!arrayOfQMC.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQMC.push(randomNumber);


        }else if(type == "QO"){

            while (!bool){
                randomNumber = Math.floor(Math.random() * this.state.maxQO) + 1;
                if(!arrayOfQO.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQO.push(randomNumber);


        }else{

            while (!bool){
                randomNumber = Math.floor(Math.random() * this.state.maxQTF) + 1;
                if(!arrayOfQTF.includes(randomNumber)){
                    bool=true;
                }
            }
            arrayOfQTF.push(randomNumber);
            
        }

    }

    set(){
        for(var j=0; j < 10; j++){
            this.genareteIdOfQuestion(j);
        }
    }

    async getNumberOfQuestions(questionType) {

        // Get items from localStorage
        const usernameValue = localStorage.getItem("username");
        const verifierValue = localStorage.getItem("key");
        
        const response = await fetch('https://trailobyte-275015.ew.r.appspot.com/rest/question/getLastID?type=' + questionType + 'ID', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'username' : usernameValue,
                'Authorization' : 'Bearer ' + verifierValue,
            },
        }).then(async (response) => {   
            const data = await response.json();
            //this.setState({Q: json});
            //await this.setQ(json);
            console.log(data);

            if (questionType == 'QMC')
                this.setState({maxQMC: data});
            else if (questionType == 'QO')
                this.setState({maxQO: data});
            else if (questionType == 'QTF')
                this.setState({maxQTF: data});
        }).catch(error => alert("Server not available"));

    }




    render(){
        return(
            <div className="quizzDo">
                <button onClick={this.gotoApp}>Back</button>
                <h1>Quizz</h1>
                <div className="allQuestions">
                    {this.state.questionQMC.map((question,idx) => {
                        return(
                            <div key={"QMC_" + idx}>
                                <h2>Question {idx + 1}</h2>
                                <QuizzQMC question = {question} nr={idx} parentCallback = {this.callBackAnswersQMC} ref ={`Question${idx}`}></QuizzQMC>
                            </div>
                        );
                    })}
                    {this.state.questionQO.map((question,idx) => {
                        return(
                            <div key={"QO_" + idx}>
                                <h2>Question {idx + arrayOfQMC.length + 1}</h2>
                                <QuizzQO question = {question} nr={idx} parentCallback = {this.callBackAnswersQO} ref ={`Question${idx+arrayOfQMC.length}`} ></QuizzQO>
                            </div>
                        );
                    })}
                    {this.state.questionQTF.map((question,idx) => {
                        return(
                            <div key={"QTF_" + idx}>
                                <h2>Question {idx + arrayOfQMC.length + arrayOfQO.length + 1}</h2>
                                <QuizzQTF question = {question} nr={idx} parentCallback = {this.callBackAnswersQTF} ref ={`Question${idx+arrayOfQMC.length + arrayOfQO.length}`}></QuizzQTF>
                            </div>
                        );
                    })}

                   <input type="submit" onClick ={this.callbacktest} value = "Submit"/>         
                </div>
            
            </div>
        );
    }
}
export default withRouter(quizzDo);