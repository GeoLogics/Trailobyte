import React from 'react';
import history from '../../history';
import NavBar from "../utils/navbar";
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';
import Slide from '../SlideShow/SlideShow3';



const useStyles = makeStyles((theme) => ({

    root:{
        backgroundImage: "url('/imagens/montanha.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        width: "100%",
        height: "100%",
        minWidth: "70em",
        minHeight: "60.55em",
        position: "absolute",
    },
    button:{
        backgroundColor: "#555555", 
        border: "none",
        color: "rgb(248, 248, 248)",
        padding: "15px 32px",
        textAlign: "center",
        textDecoration: "none",
        display: "inline-block",
        fontSize: "18px",
        width: "200px",
    },
    h:{
        textAlign: "center",
        fontSize: "xx-large",
        marginTop: "40%",
        color: "white",

    },
    paper:{
        marginTop:"5%",
        marginRight:"5%"
    }

}));

export default function Trail(){

    const classes = useStyles();

    const gotoAppViewTrail = () => {
        history.push("/viewlist");
    }

    const gotoAppPostTrail = () =>{
        history.push("/postTrail");
    }


        return(
            <div className={classes.root}>
                <NavBar></NavBar>
                <Grid container>
                    <Grid item xs={5}>
                        <h2 className={classes.h}>Trail</h2>
                        <Grid container spacing={3}  
                            direction="column"
                            justify="center"
                            alignItems="center"> 
                            <Grid item xs={6}>
                                <input type="submit" className={classes.button} onClick ={gotoAppViewTrail} value = "View Trails"/>
                            </Grid>
                            <Grid item xs={6}>        
                                <input type="submit" className={classes.button} onClick ={gotoAppPostTrail} value = "Post Trail"/>              
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={7} >
                        <Paper elevation={3} className={classes.paper}>
                            <Slide/>
                        </Paper>
                    </Grid>
                </Grid>
                </div>
            );
    }