import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import ListSubheader from '@material-ui/core/ListSubheader';
import IconButton from '@material-ui/core/IconButton';
import InfoIcon from '@material-ui/icons/Info';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Rating from '@material-ui/lab/Rating';
import history from '../../history';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    overflow: 'hidden',
    position: "relative",
    marginTop:"5%",
  },
  gridList: {
    height: "100%",
    width:"90%",
    padding: "20px 20px",
  },
  griditem:{
    marginTop: "50px",
  },
  icon: {
    color: 'rgba(255, 255, 255, 0.54)',
  },
  card:{
    width:"90%",
    height:"100%",
  },
  media: {
    height: 130,
  },
  button:{
    backgroundColor: "#555555", 
    border: "none",
    color: "rgb(248, 248, 248)",
    padding: "15px 32px",
    textAlign: "center",
    textDecoration: "none",
    display: "inline-block",
    fontSize: "18px",
    width: "200px",
    marginTop:"10%",
    marginLeft:"50%",
    transform: "translate(-50%, -50%)",
    msTransform:"translate(-50%, -50%)"
},
h10:{
    textAlign: "center",
    fontSize: "xx-large",
    marginTop: "10%",
    color: "white",
},
divex:{
  width:"100%",
  height:"100%",
}
  
}));


export default function TitlebarGridList() {
  const classes = useStyles();
  const [trails,setTrails]= useState({resultList:[]});
  const [has,setHas]=useState(null);
  const [cursor,setCursor]= useState(null);
  const [hasmore, setHasmore] = useState(true);

  const gotoAppPostTrail = () =>{
    history.push("/postTrail");
}

  const redirect = (name) => {
    history.push("view/" + name);
  }

 function getTrail(){
   var temp;
 
   var headers = new Headers();
       headers.append('Accept', 'application/json');
       headers.append('Content-Type', 'application/json');
 
   fetch("https://trailobyte-275015.ew.r.appspot.com/rest/query/byUser",{
       method: 'POST',
       headers: headers,
       body: JSON.stringify({
         param: localStorage.getItem("username"),
         pageSize: 6,
         cursor: cursor,
     })
   }).then( async (response) => {
       temp = await response.json();
       setTrails(temp);
       setHas(has+temp.resultList.length);
       setCursor(temp.cursor);
        if(temp.resultList.length < 6){
            setHasmore(false);
        }
   })
 }

 useEffect(()=> {
   getTrail();
},[]);

  return (
    <div className={classes.root}>
      {has ?
      <GridList cellHeight={300} className={classes.gridList} spacing={15} cols={3}>
        {trails.resultList.map((trail) => (
          <GridListTile key={trail.name}  className={classes.griditem}>
          <Card className={classes.card}>
          {trail.trailImg ? <CardMedia
              className={classes.media}
              component="img"
              alt={trail.name}
              src={trail.trailImg}
              title={trail.name}
            /> : <CardMedia
            className={classes.media}
            component="img"
            alt={trail.name}
            src={"/imagens/montanha.jpg"}
            title={trail.name}
          />}
            <CardContent>
              <Typography gutterBottom variant="h5" component="h2">
                {trail.name}
              </Typography>
              <Typography variant="body2" color="textSecondary" component="p">
                {trail.description}
              </Typography>
            </CardContent>
          <CardActions>
            <Button size="small" color="primary" onClick={redirect(trail.name)}>
              Details
            </Button>
            <Rating name="read-only" value={trail.avgRating} readOnly />
          </CardActions>
        </Card>
        </GridListTile>
        ))}
      </GridList>
      : <div className={classes.divex}>
        <h1 className={classes.h10}>There's no trail posted</h1>
        <input type="submit" className={classes.button} onClick ={gotoAppPostTrail} value = "Post Trail"/>
        </div> }
    </div>
  );
}