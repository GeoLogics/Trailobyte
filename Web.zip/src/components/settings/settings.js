import React ,{useState} from 'react';
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tab from '@material-ui/core/Tab';
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import NavBar from '../utils/navbar';
import Perfil from "./perfil";
import Mytrails from "./mytrails";
import { lightGreen } from '@material-ui/core/colors';

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundImage: "url('/imagens/montanha.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    width: "100%",
    minWidth: "70em",
    minHeight: "60.55em",
    position: "absolute",
    backgroundAttachment: "fixed",
  },
  tabs:{
    backgroundColor: "#8c8c8c",
    indicatorColor: theme.palette.secondary.main,
  }
}));

const theme = createMuiTheme({
  palette: {
    secondary: {
      main: lightGreen[500],
    },
  },
});

export default function LabTabs() {
  const classes = useStyles();
  const [value, setValue] = useState('1');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div className={classes.root}>
        <NavBar></NavBar>
      <TabContext value={value}>
        <AppBar position="static">
          <ThemeProvider theme={theme}>
          <TabList onChange={handleChange} aria-label="simple tabs example" className={classes.tabs}>
            <Tab label="My account" value="1" />
            <Tab label="My trails" value="2" />
          </TabList>
          </ThemeProvider>
        </AppBar>
        <TabPanel value="1"><Perfil/></TabPanel>
        <TabPanel value="2"><Mytrails/></TabPanel>
      </TabContext>
    </div>
  );
}