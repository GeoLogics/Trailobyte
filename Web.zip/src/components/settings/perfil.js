import React,{ Component, useEffect, useState} from "react";
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import SaveIcon from '@material-ui/icons/Save';
import {green} from '@material-ui/core/colors';



const useStyles = makeStyles((theme) => ({
    paper: {
        width: "100%",
        height: "100px",
        backgroundColor: "#d6d6c2",
    },
    grid: {
        width: "50%",
    },
    label:{
        paddingRight: "20px",
        paddingLeft: "20px",
        color: "black",
    },
    input:{
        width: "90%",
        backgroundColor:"#f4f4f0"
    },
    div:{
        padding: "20px 20px",
    },
    divinput:{
        flexGrow: "1!important",
        float: "right",
        width: "80%"

    },
    p:{
        fontSize: "80%",
    },

    divheader:{
        textAlign: "center",
        fontSize: "150%",
        color: "#d6d6c2",
        textShadow: "1px 1px black",
        marginTop:"4%"
    },
    submit:{
        float: "right",
        marginTop:"2%",
        marginRight:"26%",
        
    },

}));

const theme = createMuiTheme({
    palette: {
      primary: {
        main: '#8c8c8c',
      }
    },
  });


export default function Perfil(){
        const classes = useStyles();

        const username = localStorage.getItem("username");
        const [email,setEmail] = useState(null);
        const [telefone,setTelefone] = useState(null);
        const [mobile,setMobile] = useState(null);
        const [address,setAddress] = useState(null);

        useEffect(()=> {
           getPerfil(username);
        },[]);

        function update(username,email,telefone,mobile,address){
            const key = localStorage.getItem("key");
        
            var headers = new Headers();
                headers.append('username', username);
                headers.append('Authorization','Bearer '+ key);
                headers.append('Content-Type', 'application/json');

                console.log(username);
                console.log(email);
                console.log(telefone);
                console.log(mobile);
                console.log(address);
        
            fetch("https://trailobyte-275015.ew.r.appspot.com/rest/update/v1",{
                method: 'PUT',
                headers: headers,
                body: JSON.stringify({
                    username:username,
                    email:email,
                    telephone:telefone,
                    mobilePhone:mobile,
                    address:address,
                })
            }).then( async (response) => {
                var temp = await response;
            }).catch(error => alert("Server not available"));
        }

        function getPerfil(username){
            var temp;
            const key = localStorage.getItem("key");
        
            var headers = new Headers();
                headers.append('username', username);
                headers.append('Authorization','Bearer '+ key);
                headers.append('Accept', 'application/json');
        
            fetch("https://trailobyte-275015.ew.r.appspot.com/rest/list/v1",{
                method: 'GET',
                headers: headers,
            }).then( async (response) => {
                temp = await response.json();
                setEmail(temp.email);
                setTelefone(temp.telephone);
                setMobile(temp.mobilePhone);
                setAddress(temp.address);
            })
        }

    

        return(
            <div>
            <div className={classes.divheader}>
                <h3>Profile Settings</h3>
                <div>
                    <p>Change your account details</p>
                </div>
            </div>
            <div>
            <Grid container spacing={3} 
            direction="column"
            justify="center"
            alignItems="center">
                <Grid item xs={8} className={classes.grid}>
                    <Paper elevation={3} className={classes.paper}>
                        <div className={classes.div}>
                            <label className={classes.label}>Email</label>
                        <div className={classes.divinput}>
                            <input type="text" value={email} className={classes.input} onChange={e => setEmail(e.target.value)}></input>
                            <p className={classes.p}>You may update your email</p>
                        </div>
                        </div>
                    </Paper>
                </Grid>
                <Grid item xs={8} className={classes.grid}>
                    <Paper elevation={3} className={classes.paper}>
                    <div className={classes.div}>
                            <label className={classes.label}>Phone</label>
                        <div className={classes.divinput}>
                            <input type="text" value={telefone} className={classes.input} onChange={e => setTelefone(e.target.value)}></input>
                            <p className={classes.p}>You may update your Phone number</p>
                        </div>
                        </div>
                    </Paper>
                </Grid>
                <Grid item xs={8} className={classes.grid}>
                    <Paper elevation={3} className={classes.paper}>
                    <div className={classes.div}>
                            <label className={classes.label}>Mobile</label>
                        <div className={classes.divinput}>
                            <input type="text" value={mobile} className={classes.input} onChange={e => setMobile(e.target.value)}></input>
                            <p className={classes.p}>You may update your mobile</p>
                        </div>
                        </div>
                    </Paper>
                </Grid>
                <Grid item xs={8} className={classes.grid}>
                    <Paper elevation={3} className={classes.paper}>
                    <div className={classes.div}>
                            <label className={classes.label}>Address</label>
                        <div className={classes.divinput}>
                            <input type="text" value={address} className={classes.input} onChange={e => setAddress(e.target.value)}></input>
                            <p className={classes.p}>You may update your address</p>
                        </div>
                        </div>
                    </Paper>
                </Grid>
            </Grid>
            </div>
            <ThemeProvider theme={theme}>
            <Button
                variant="contained"
                nClick={(()=>update(username,email,telefone,mobile,address))}
                className={classes.submit}
                color="primary"
            >
        SAVE
        </Button>
        </ThemeProvider>
            </div>
        );
}


