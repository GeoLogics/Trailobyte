import React,{ Component } from "react";
import { withRouter } from "react-router-dom";
import "./logout.css";
import history from '../../history';

class logout extends Component{

    constructor(){
        super();
        this.logout();
    }

    gotoApp(){
        history.push("/");
    }

    logout(){
        var username = localStorage.getItem("username");
        var key = localStorage.getItem("key");
        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/logout/v1', {
            method: 'DELETE',
            headers: {
                'username': username,
                'Authorization': 'Bearer '+ key,
            }
        })
        .then(async (response) => {
            var res = await response;
            if(res.ok){
                localStorage.clear();
        }
    }).catch(error => alert("Server not available"));     
        
    }

    render(){
        return(
            <div className="logout">
                <button onClick={this.gotoApp}>Back</button>
                <h2>Logout</h2>
                <p>Have a good day!</p>
                <p>Come again!</p>
            </div>
        );

    }
}

export default withRouter(logout);