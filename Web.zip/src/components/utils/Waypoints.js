import React from 'react';
import { makeStyles } from '@material-ui/core';


const useStyle = makeStyles((theme) => ({
    desc:{
        width: "100%"
    }
}));

export default function waypoints(props){
    const mark = props.mark;
    const classes = useStyle();

    return(
        <div>
            <p>{mark.name}</p>
            <p className={classes.desc}>{mark.content}</p>
            <p>Coords: lat:{mark.coords.lat} lng:{mark.coords.lng}</p>
        </div>
        
        );
}