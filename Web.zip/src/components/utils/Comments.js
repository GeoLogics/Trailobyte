import React, {useState , useEffect} from 'react';
import Paper from '@material-ui/core/Paper';
import Pagination from '@material-ui/lab/Pagination';
import Rating from '@material-ui/lab/Rating';
import {Button, Grid} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    large: {
        width: theme.spacing(7),
        height: theme.spacing(7),
        float:"left",
      },
    h: {
        width: "300px",
    },
    paper1:{
        width: "90%",
        backgroundColor:"#eaeae1",
    },
    root:{
        backgroundColor:"#eaeae1",
    },
    textarea:{
        maxWidth:"100%",
        maxHeight:"80px",
        minWidth:"100%",
        minHeight:"80px"
    },
    button:{
        marginLeft:"10px"
    },
    h:{
        marginBottom:"5px"
    },
    comment:{
        fontSize:"15px"
    }

}));

export default function comments(props){
    const classes = useStyles();
    const [comments,setComments] = useState([]);
    const [page,setPage] = useState(1);
    const [isWriting,setWriting] = useState(false);
    const [message,setMessage] = useState('');
    const [rating,setRating] = useState(5);
    const [ratingFinal,setRatingFinal] = useState(5);
    const [nocomments,setNocomments] = useState(true);

    const handleChange = (event, value) => {
        setPage(value);
      };

      const handleChangeMessage = (event) => {
        setMessage(event.target.value);
      };
    
    useEffect(() => {
        setComments(props.comments);
        if(props.comments.length == 0){
            setNocomments(false);
            setWriting(true);
        }
    },[]);



       const submit = () => {
        const username = localStorage.getItem("username");
        const key = localStorage.getItem("key");
        var myHeaders = new Headers();
            myHeaders.append("username", username);
            myHeaders.append("Authorization", "Bearer " + key);
            myHeaders.append("content-type", "application/json");
        
        var comment = {
            author:username,
            trailName: props.name,
            comment:message,
            rating:rating,
        };

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify(comment),
        };

         fetch('https://trailobyte-275015.ew.r.appspot.com/rest/trail/OPT4OP',requestOptions)
        .then(async (response) =>{ 
                var temp = await response;
                if(temp.ok){
                    setComments(comments.concat(comment));
                    console.log(comment);
                    setNocomments(true);
                    setWriting(false);
                }
            })
            .catch(error => alert("Server not available"));
        };
    
    
    return(
       <div>
        {isWriting ? <div>{nocomments ? <div>
            <textarea placeholder="Type your comment" id="description" value = {message} onChange={handleChangeMessage} className={classes.textarea} maxLength={200}></textarea>
            <Grid container>
                <Grid item xs ={12}>
            <Rating
                name="hover-feedback"
                value={rating}
                precision={0.5}
                onChange={(event, newValue) => {
                    setRating(newValue);
                    }}
                onChangeActive={(event, newHover) => {
                    setRatingFinal(newHover);
                    }}
                />
                </Grid>
                <Grid item xs={12}>
                <Button variant="contained" color="primary" onClick={submit}>Submit</Button>
                <Button variant="contained" color="secondary" className={classes.button} onClick={() => {
                    setWriting(false);
                }}> Cancel</Button>
                </Grid>
                </Grid>
        </div> :  <div>
        <textarea placeholder="Be the first one to comment" id="description" value = {message} onInput={handleChangeMessage} className={classes.textarea} maxLength={200}></textarea>
        <Grid container>
            <Grid item xs ={12}>
        <Rating
            name="hover-feedback"
            value={rating}
            precision={0.5}
            onChange={(event, newValue) => {
                setRating(newValue);
                }}
            onChangeActive={(event, newHover) => {
                setRatingFinal(newHover);
                }}
            />
            </Grid>
            <Grid item xs={12}>
            <Button variant="contained" color="primary" onClick={submit}>Submit</Button>
            <Button variant="contained" color="secondary" className={classes.button} onClick={() => {
                setWriting(false);
            }}> Cancel</Button>
            </Grid>
            </Grid>
    </div>}</div> : 
        <div>
        <Paper elevation={1}>
            {comments.map((comments,index) => {
                if(page-1 === index){
                    return(
                    <div key={index}>
                        <h5 className={classes.h}>{comments.author}</h5>
                        <p className={classes.comment}>{comments.comment}</p>
                        <Rating name="read-only" value={comments.rating} readOnly/>
                    </div>
                    );
                }
                else{
                    return(null);
                }
            })}
        </Paper>

        <Pagination count={comments.length} page={page} size="small"  onChange={handleChange}/>
        <Button variant="contained" onClick={() => { setWriting(true)}}>Comment</Button>
        </div>
            }
        </div>
    );
}