import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import ListSubheader from '@material-ui/core/ListSubheader';
import IconButton from '@material-ui/core/IconButton';
import InfoIcon from '@material-ui/icons/Info';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import history from '../../history';
import Rating from '@material-ui/lab/Rating';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    overflow: 'hidden',
    position: "relative",

  },
  gridList: {
    height: "100%",
    width:"90%",
    padding: "20px 20px",
  },
  griditem:{
    marginTop: "50px",
  },
  icon: {
    color: 'rgba(255, 255, 255, 0.54)',
  },
  card:{
    width:"90%",
    height:"100%",
  },
  media: {
    height: 130,
  },
  button:{
      color: "white", 
      marginLeft: "10%",
  }
}));


function redirect(name){
    history.push("/view/"+name);
}

function redirect2(){
  history.push("/viewlist");
}


export default function TitlebarGridList() {
  const classes = useStyles();
  const [trails,setTrails]= useState({resultList:[]});

  function getTrail(){
    var temp;
  
    var headers = new Headers();
        headers.append('Accept', 'application/json');
        headers.append('Content-Type', 'application/json');
  
    fetch("https://trailobyte-275015.ew.r.appspot.com/rest/query/byRating",{
        method: 'POST',
        headers: headers,
        body: JSON.stringify({
          pageSize: 6,
          cursor: null,
      })
    }).then( async (response) => {
        temp = await response.json();
        setTrails(temp);
    })
  }

  useEffect(()=> {
    getTrail();
 },[]);

  return (
    <div className={classes.root}>
      <GridList cellHeight={300} className={classes.gridList} spacing={15} cols={3}>
        {trails.resultList.map((trail) => (
          <GridListTile key={trail.name}  className={classes.griditem}>
          <Card className={classes.card}>
          {trail.trailImg ? <CardMedia
              className={classes.media}
              component="img"
              alt={trail.name}
              src={trail.trailImg}
              title={trail.name}
            /> : <CardMedia
            className={classes.media}
            component="img"
            alt={trail.name}
            src={"/imagens/montanha.jpg"}
            title={trail.name}
          />}
            <CardContent>
              <Typography gutterBottom variant="h5" component="h2">
                {trail.name}
              </Typography>
              {trail.description ? <Typography gutterBottom variant="body2" color="textSecondary" component="p">
                {trail.description}
              </Typography> :<Typography gutterBottom variant="body2" color="textSecondary" component="p">
                Does not have description
              </Typography>}
            </CardContent>
          <CardActions>
            <Button size="small" color="primary" onClick={()=>redirect(trail.name)}>
              Details
            </Button>
            <Rating name="read-only" value={trail.avgRating} readOnly />
          </CardActions>
        </Card>
        </GridListTile>
        ))}
      </GridList>
      <Button className={classes.button} onClick={()=>redirect2()}>View more</Button>
    </div>
  );
}