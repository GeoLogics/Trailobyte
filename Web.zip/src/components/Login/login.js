import React, { Component } from 'react';
import './login.css';
import { withRouter } from "react-router-dom";
import history from '../../history';
import { render } from 'react-dom';
import { Alert, AlertTitle } from '@material-ui/lab';
import IconButton from '@material-ui/core/IconButton';
import Collapse from '@material-ui/core/Collapse';
import Button from '@material-ui/core/Button';
import CloseIcon from '@material-ui/icons/Close';

class login extends Component {
    constructor(){
        super();
        this.state = {
            username: '',
            password: '',
            error:'',
            open: false,
            token:''
        };

        this.submit = this.submit.bind(this);
        this.gotoApp = this.gotoApp.bind(this);
        this.usernameChange = this.usernameChange.bind(this);
        this.passwordChange = this.passwordChange.bind(this);
        this.DefaultError = this.DefaultError.bind(this);
    }


    DefaultError() {
        this.setState({ error: '' ,
                        open: false});
    }



    submit(event){
        event.preventDefault();


        if(!this.state.username){
            return this.setState({error: 'Username invalido',
                                    open: true});
        }

        if(!this.state.password){
            return this.setState({error: 'Password invalido',
                                    open: true});
        }
        
        this.login(this.state.username,this.state.password);
        return this.setState({ error: '' });
    }

    gotoHome(){ 
        history.push("/home");
    }

    usernameChange(event){
        this.setState({username: event.target.value});
    };

    passwordChange(event){
        this.setState({password: event.target.value});
    }

    gotoApp(){
        history.push("/");
    }

    login(username, password){ 
        fetch('https://trailobyte-275015.ew.r.appspot.com/rest/login/v1', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                password: password,
            })
        })

        .then(async (response) => {
            if(response.ok){
                var temp = await response.json();
                console.log(temp);
                var key = temp.verifier;
                var role = temp.role;
                localStorage.removeItem("key");
                localStorage.removeItem("role");
                localStorage.removeItem("username");
                if(key != null){
                    localStorage.setItem("key",key);
                    localStorage.setItem("username",username);
                    localStorage.setItem("role",role);
                }
                this.gotoHome();
            }
            else if(response.status == 403){
                this.setItem({open: true});
            }
            })
            .catch(error => alert("Server not available"));
        }
        
    
    render(){
        return(
            <div className="login">
                <button className="backbutton" onClick={this.gotoApp}>Back</button>
                <form onSubmit={this.submit}>
                    {
                    <Collapse in={this.state.open}>
                        <Alert severity="error"
                        action={
                            <IconButton
                              aria-label="close"
                              color= "inherit"
                              size="small"
                              onClick={() => {
                                this.setState({open:false});
                              }}
                            >
                              <CloseIcon fontSize="inherit" />
                            </IconButton>
                          }
                          >
                            <AlertTitle>Login failed!</AlertTitle>
                            Please check your username or password!
                        </Alert>
                    </Collapse>
                    }
                <h2>Login</h2>
                <div className="user">
                    <input type="text" placeholder="Username" data-test="username" value = {this.state.username} onChange={this.usernameChange}/>
                </div>
                <div className="pass">
                    <input type="password" placeholder="Password" data-test="password" value = {this.state.password} onChange={this.passwordChange}/>
                </div>
                <div className="submitlogin">
                    <input type="submit"  value = "Login" data-test = "submit"/>
                    <p >No account? <a href="register">Click here</a></p>                
                </div>
                </form>
            </div>
        );
    }
}

    export default withRouter(login);