import React from "react";
import './Home.css';
import { withRouter } from "react-router-dom";
import NavBar from "../utils/navbar";
import Content from "../utils/Contenthome";



class Home extends React.Component {

    render() {
        return (
            <div className="home">
                <header className="headerhome">
                    <div className="header-text">
                    <a>Come and discover our trails</a>
                    </div>
                </header>
                <NavBar></NavBar>
                <div className="content">
                    <Content></Content>
                </div>
            </div>
        );
    }
}

export default withRouter(Home);